import React, { useState } from 'react';
import { ChurchProvider } from './context/ChurchContext';
import { Navigation, ActiveTab } from './components/Navigation';
import { OverviewTab } from './components/Dashboard/OverviewTab';
import { MembersTab } from './components/Members/MembersTab';
import { GivingTab } from './components/Giving/GivingTab';
import { GroupsTab } from './components/Groups/GroupsTab';
import { EventsTab } from './components/Events/EventsTab';
import { CheckInTab } from './components/CheckIn/CheckInTab';
import { PastoralCareTab } from './components/PastoralCare/PastoralCareTab';

import { AddMemberModal } from './components/Members/AddMemberModal';
import { RecordGiftModal } from './components/Giving/RecordGiftModal';
import { OnlineGivingPortalModal } from './components/Giving/OnlineGivingPortalModal';
import { TaxStatementModal } from './components/TaxStatement/TaxStatementModal';
import { CheckInKioskModal } from './components/CheckIn/CheckInKioskModal';
import { QuickAddModal } from './components/QuickAddModal';
import { Member } from './types';

export function ChMSApp() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');

  // Modals state
  const [isAddMemberOpen, setIsAddMemberOpen] = useState(false);
  const [isRecordGiftOpen, setIsRecordGiftOpen] = useState(false);
  const [isGivingPortalOpen, setIsGivingPortalOpen] = useState(false);
  const [isKioskOpen, setIsKioskOpen] = useState(false);
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [taxStatementMember, setTaxStatementMember] = useState<Member | null>(null);

  const handleGenerateTaxStatement = (member: Member) => {
    setTaxStatementMember(member);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans-ui text-slate-900">
      
      {/* Top Navigation conforming to Top Bar Contract */}
      <Navigation
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        onLaunchKiosk={() => setIsKioskOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'overview' && (
          <OverviewTab
            onNavigateTab={setActiveTab}
            onRecordDonation={() => setIsRecordGiftOpen(true)}
            onAddMember={() => setIsAddMemberOpen(true)}
            onLaunchKiosk={() => setIsKioskOpen(true)}
          />
        )}

        {activeTab === 'members' && (
          <MembersTab
            onOpenAddModal={() => setIsAddMemberOpen(true)}
            onGenerateTaxStatement={handleGenerateTaxStatement}
          />
        )}

        {activeTab === 'giving' && (
          <GivingTab
            onOpenRecordGift={() => setIsRecordGiftOpen(true)}
            onOpenGivingPortal={() => setIsGivingPortalOpen(true)}
            onGenerateTaxStatement={handleGenerateTaxStatement}
          />
        )}

        {activeTab === 'groups' && <GroupsTab />}

        {activeTab === 'events' && <EventsTab />}

        {activeTab === 'checkin' && <CheckInTab />}

        {activeTab === 'care' && <PastoralCareTab />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <div className="flex items-center gap-2">
            <span className="font-display font-semibold text-slate-800">GracePoint ChMS</span>
            <span>·</span>
            <span>Church Management Software</span>
          </div>

          <div className="flex items-center gap-4 text-slate-500">
            <span>Members</span>
            <span>·</span>
            <span>Online Giving</span>
            <span>·</span>
            <span>Small Groups</span>
            <span>·</span>
            <span>Volunteer Roster</span>
            <span>·</span>
            <span>Sunday Check-in</span>
          </div>
        </div>
      </footer>

      {/* Modals & Dialogs */}
      <AddMemberModal
        isOpen={isAddMemberOpen}
        onClose={() => setIsAddMemberOpen(false)}
      />

      <RecordGiftModal
        isOpen={isRecordGiftOpen}
        onClose={() => setIsRecordGiftOpen(false)}
      />

      <OnlineGivingPortalModal
        isOpen={isGivingPortalOpen}
        onClose={() => setIsGivingPortalOpen(false)}
      />

      <TaxStatementModal
        member={taxStatementMember}
        onClose={() => setTaxStatementMember(null)}
      />

      <CheckInKioskModal
        isOpen={isKioskOpen}
        onClose={() => setIsKioskOpen(false)}
      />

      <QuickAddModal
        isOpen={isQuickAddOpen}
        onClose={() => setIsQuickAddOpen(false)}
        onAddMember={() => setIsAddMemberOpen(true)}
        onRecordGift={() => setIsRecordGiftOpen(true)}
        onLaunchKiosk={() => setIsKioskOpen(true)}
        onNavigateTab={setActiveTab}
      />

    </div>
  );
}

export default function App() {
  return (
    <ChurchProvider>
      <ChMSApp />
    </ChurchProvider>
  );
}
