import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Member, 
  Household, 
  Donation, 
  ChurchGroup, 
  ChurchEvent, 
  CheckInRecord, 
  GuestFollowUp, 
  GeneralPrayerRequest,
  Campus,
  PastoralNote
} from '../types';
import {
  INITIAL_MEMBERS,
  INITIAL_HOUSEHOLDS,
  INITIAL_DONATIONS,
  INITIAL_GROUPS,
  INITIAL_EVENTS,
  INITIAL_CHECKINS,
  INITIAL_GUEST_FOLLOWUPS,
  INITIAL_PRAYER_REQUESTS
} from '../data/initialData';

interface ChurchContextType {
  members: Member[];
  households: Household[];
  donations: Donation[];
  groups: ChurchGroup[];
  events: ChurchEvent[];
  checkIns: CheckInRecord[];
  guestFollowUps: GuestFollowUp[];
  prayerRequests: GeneralPrayerRequest[];
  activeCampus: Campus | 'All Campuses';
  setActiveCampus: (campus: Campus | 'All Campuses') => void;

  // Member actions
  addMember: (memberData: Omit<Member, 'id' | 'createdAt' | 'pastoralNotes'>) => string;
  updateMember: (id: string, updates: Partial<Member>) => void;
  deleteMember: (id: string) => void;
  addPastoralNote: (memberId: string, note: Omit<PastoralNote, 'id'>) => void;

  // Giving actions
  addDonation: (donationData: Omit<Donation, 'id' | 'receiptNumber'>) => Donation;

  // Group actions
  addGroup: (groupData: Omit<ChurchGroup, 'id' | 'discussions' | 'prayerRequests'>) => void;
  updateGroup: (id: string, updates: Partial<ChurchGroup>) => void;
  addGroupDiscussion: (groupId: string, author: string, content: string) => void;
  addGroupPrayerRequest: (groupId: string, author: string, request: string) => void;
  toggleGroupPrayerAnswered: (groupId: string, prayerId: string) => void;

  // Event actions
  addEvent: (eventData: Omit<ChurchEvent, 'id'>) => void;
  assignVolunteer: (eventId: string, slotId: string, memberId: string) => void;
  removeVolunteer: (eventId: string, slotId: string, memberId: string) => void;
  toggleEventRsvp: (eventId: string, memberId: string) => void;

  // Check-In actions
  checkInChild: (params: {
    childId: string;
    serviceId: string;
    serviceName: string;
    roomName: string;
    medicalNotes?: string;
  }) => CheckInRecord;
  checkOutChild: (checkInId: string, providedCode: string) => { success: boolean; message: string };

  // Pastoral Care actions
  updateGuestStage: (id: string, stage: GuestFollowUp['stage']) => void;
  addGuestFollowUp: (guest: Omit<GuestFollowUp, 'id'>) => void;
  togglePrayerStatus: (id: string, answeredNote?: string) => void;
  addPrayerRequest: (request: Omit<GeneralPrayerRequest, 'id' | 'dateSubmitted' | 'status'>) => void;

  resetToDemoData: () => void;
}

const STORAGE_KEYS = {
  MEMBERS: 'gracepoint_chms_members_v1',
  HOUSEHOLDS: 'gracepoint_chms_households_v1',
  DONATIONS: 'gracepoint_chms_donations_v1',
  GROUPS: 'gracepoint_chms_groups_v1',
  EVENTS: 'gracepoint_chms_events_v1',
  CHECKINS: 'gracepoint_chms_checkins_v1',
  GUESTS: 'gracepoint_chms_guests_v1',
  PRAYERS: 'gracepoint_chms_prayers_v1',
};

const ChurchContext = createContext<ChurchContextType | undefined>(undefined);

export const ChurchProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [members, setMembers] = useState<Member[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MEMBERS);
    return saved ? JSON.parse(saved) : INITIAL_MEMBERS;
  });

  const [households, setHouseholds] = useState<Household[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.HOUSEHOLDS);
    return saved ? JSON.parse(saved) : INITIAL_HOUSEHOLDS;
  });

  const [donations, setDonations] = useState<Donation[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.DONATIONS);
    return saved ? JSON.parse(saved) : INITIAL_DONATIONS;
  });

  const [groups, setGroups] = useState<ChurchGroup[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.GROUPS);
    return saved ? JSON.parse(saved) : INITIAL_GROUPS;
  });

  const [events, setEvents] = useState<ChurchEvent[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.EVENTS);
    return saved ? JSON.parse(saved) : INITIAL_EVENTS;
  });

  const [checkIns, setCheckIns] = useState<CheckInRecord[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CHECKINS);
    return saved ? JSON.parse(saved) : INITIAL_CHECKINS;
  });

  const [guestFollowUps, setGuestFollowUps] = useState<GuestFollowUp[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.GUESTS);
    return saved ? JSON.parse(saved) : INITIAL_GUEST_FOLLOWUPS;
  });

  const [prayerRequests, setPrayerRequests] = useState<GeneralPrayerRequest[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PRAYERS);
    return saved ? JSON.parse(saved) : INITIAL_PRAYER_REQUESTS;
  });

  const [activeCampus, setActiveCampus] = useState<Campus | 'All Campuses'>('All Campuses');

  // Persistence
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MEMBERS, JSON.stringify(members));
  }, [members]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.HOUSEHOLDS, JSON.stringify(households));
  }, [households]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DONATIONS, JSON.stringify(donations));
  }, [donations]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.GROUPS, JSON.stringify(groups));
  }, [groups]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.EVENTS, JSON.stringify(events));
  }, [events]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CHECKINS, JSON.stringify(checkIns));
  }, [checkIns]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.GUESTS, JSON.stringify(guestFollowUps));
  }, [guestFollowUps]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PRAYERS, JSON.stringify(prayerRequests));
  }, [prayerRequests]);

  // Member Handlers
  const addMember = (memberData: Omit<Member, 'id' | 'createdAt' | 'pastoralNotes'>): string => {
    const newId = `mem-${Date.now().toString(36)}`;
    const initials = `${memberData.firstName[0] || ''}${memberData.lastName[0] || ''}`.toUpperCase();
    const newMember: Member = {
      ...memberData,
      id: newId,
      avatarInitial: memberData.avatarInitial || initials,
      pastoralNotes: [],
      createdAt: new Date().toISOString().split('T')[0],
    };

    setMembers(prev => [newMember, ...prev]);

    // If assigned to a household, update the household
    if (memberData.householdId) {
      setHouseholds(prev => prev.map(hh => {
        if (hh.id === memberData.householdId && !hh.memberIds.includes(newId)) {
          return { ...hh, memberIds: [...hh.memberIds, newId] };
        }
        return hh;
      }));
    }

    return newId;
  };

  const updateMember = (id: string, updates: Partial<Member>) => {
    setMembers(prev => prev.map(m => m.id === id ? { ...m, ...updates } : m));
  };

  const deleteMember = (id: string) => {
    setMembers(prev => prev.filter(m => m.id !== id));
    // Also remove from households
    setHouseholds(prev => prev.map(hh => ({
      ...hh,
      memberIds: hh.memberIds.filter(mId => mId !== id)
    })));
  };

  const addPastoralNote = (memberId: string, note: Omit<PastoralNote, 'id'>) => {
    const noteId = `note-${Date.now()}`;
    setMembers(prev => prev.map(m => {
      if (m.id === memberId) {
        return {
          ...m,
          pastoralNotes: [{ ...note, id: noteId }, ...m.pastoralNotes]
        };
      }
      return m;
    }));
  };

  // Giving Handlers
  const addDonation = (donationData: Omit<Donation, 'id' | 'receiptNumber'>): Donation => {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0].replace(/-/g, '');
    const randomSuffix = Math.floor(100 + Math.random() * 900);
    const receiptNumber = `REC-${dateStr}-${randomSuffix}`;
    const newDonation: Donation = {
      ...donationData,
      id: `don-${Date.now()}`,
      receiptNumber,
    };

    setDonations(prev => [newDonation, ...prev]);
    return newDonation;
  };

  // Group Handlers
  const addGroup = (groupData: Omit<ChurchGroup, 'id' | 'discussions' | 'prayerRequests'>) => {
    const newGroup: ChurchGroup = {
      ...groupData,
      id: `grp-${Date.now()}`,
      discussions: [],
      prayerRequests: [],
    };
    setGroups(prev => [...prev, newGroup]);
  };

  const updateGroup = (id: string, updates: Partial<ChurchGroup>) => {
    setGroups(prev => prev.map(g => g.id === id ? { ...g, ...updates } : g));
  };

  const addGroupDiscussion = (groupId: string, author: string, content: string) => {
    const newDiscussion = {
      id: `disc-${Date.now()}`,
      author,
      date: new Date().toISOString().split('T')[0],
      content,
    };
    setGroups(prev => prev.map(g => {
      if (g.id === groupId) {
        return { ...g, discussions: [newDiscussion, ...g.discussions] };
      }
      return g;
    }));
  };

  const addGroupPrayerRequest = (groupId: string, author: string, request: string) => {
    const newPrayer = {
      id: `gpr-${Date.now()}`,
      author,
      request,
      date: new Date().toISOString().split('T')[0],
      isAnswered: false,
    };
    setGroups(prev => prev.map(g => {
      if (g.id === groupId) {
        return { ...g, prayerRequests: [newPrayer, ...g.prayerRequests] };
      }
      return g;
    }));
  };

  const toggleGroupPrayerAnswered = (groupId: string, prayerId: string) => {
    setGroups(prev => prev.map(g => {
      if (g.id === groupId) {
        return {
          ...g,
          prayerRequests: g.prayerRequests.map(p => 
            p.id === prayerId ? { ...p, isAnswered: !p.isAnswered } : p
          )
        };
      }
      return g;
    }));
  };

  // Event Handlers
  const addEvent = (eventData: Omit<ChurchEvent, 'id'>) => {
    const newEvent: ChurchEvent = {
      ...eventData,
      id: `evt-${Date.now()}`,
    };
    setEvents(prev => [...prev, newEvent]);
  };

  const assignVolunteer = (eventId: string, slotId: string, memberId: string) => {
    setEvents(prev => prev.map(evt => {
      if (evt.id === eventId) {
        return {
          ...evt,
          volunteerSlots: evt.volunteerSlots.map(slot => {
            if (slot.id === slotId && !slot.assignedMemberIds.includes(memberId)) {
              return {
                ...slot,
                assignedMemberIds: [...slot.assignedMemberIds, memberId]
              };
            }
            return slot;
          })
        };
      }
      return evt;
    }));
  };

  const removeVolunteer = (eventId: string, slotId: string, memberId: string) => {
    setEvents(prev => prev.map(evt => {
      if (evt.id === eventId) {
        return {
          ...evt,
          volunteerSlots: evt.volunteerSlots.map(slot => {
            if (slot.id === slotId) {
              return {
                ...slot,
                assignedMemberIds: slot.assignedMemberIds.filter(id => id !== memberId)
              };
            }
            return slot;
          })
        };
      }
      return evt;
    }));
  };

  const toggleEventRsvp = (eventId: string, memberId: string) => {
    setEvents(prev => prev.map(evt => {
      if (evt.id === eventId) {
        const isRsvpd = evt.rsvpMemberIds.includes(memberId);
        return {
          ...evt,
          rsvpMemberIds: isRsvpd 
            ? evt.rsvpMemberIds.filter(id => id !== memberId)
            : [...evt.rsvpMemberIds, memberId]
        };
      }
      return evt;
    }));
  };

  // Check-In Handlers
  const checkInChild = ({
    childId,
    serviceId,
    serviceName,
    roomName,
    medicalNotes,
  }: {
    childId: string;
    serviceId: string;
    serviceName: string;
    roomName: string;
    medicalNotes?: string;
  }): CheckInRecord => {
    const child = members.find(m => m.id === childId);
    const household = households.find(h => h.id === child?.householdId);
    const parent = members.find(m => m.householdId === child?.householdId && (m.householdRole === 'Head' || m.householdRole === 'Spouse'));

    // Generate security alphanumeric code (e.g. M-842)
    const initial = (child?.lastName?.[0] || 'C').toUpperCase();
    const codeNum = Math.floor(100 + Math.random() * 900);
    const securityCode = `${initial}-${codeNum}`;

    const newRecord: CheckInRecord = {
      id: `chk-${Date.now()}`,
      childId,
      childName: child ? `${child.firstName} ${child.lastName}` : 'Child',
      householdId: child?.householdId || 'hh-custom',
      parentName: parent ? `${parent.firstName} ${parent.lastName}` : household?.emergencyContact.name || 'Guardian',
      parentPhone: parent?.phone || household?.emergencyContact.phone || '(555) 000-0000',
      serviceId,
      serviceName,
      roomName,
      securityCode,
      checkInTime: new Date().toISOString(),
      status: 'Checked In',
      allergies: child?.allergies || 'None recorded',
      medicalNotes: medicalNotes || (child?.allergies?.includes('EpiPen') ? 'Allergy alert: see backpack' : undefined),
    };

    setCheckIns(prev => [newRecord, ...prev]);
    return newRecord;
  };

  const checkOutChild = (checkInId: string, providedCode: string): { success: boolean; message: string } => {
    const record = checkIns.find(c => c.id === checkInId);
    if (!record) {
      return { success: false, message: 'Check-in record not found.' };
    }
    if (record.status === 'Picked Up') {
      return { success: false, message: 'This child has already been safely checked out.' };
    }
    const cleanProvided = providedCode.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
    const cleanActual = record.securityCode.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');

    if (cleanProvided !== cleanActual) {
      return { 
        success: false, 
        message: `Security code mismatch. Provided: "${providedCode.toUpperCase()}", but child's parent ticket is "${record.securityCode}".` 
      };
    }

    setCheckIns(prev => prev.map(c => {
      if (c.id === checkInId) {
        return {
          ...c,
          status: 'Picked Up',
          checkOutTime: new Date().toISOString(),
        };
      }
      return c;
    }));

    return { 
      success: true, 
      message: `${record.childName} authorized for dismissal to ${record.parentName}. Security code verified!` 
    };
  };

  // Pastoral Care Handlers
  const updateGuestStage = (id: string, stage: GuestFollowUp['stage']) => {
    setGuestFollowUps(prev => prev.map(g => g.id === id ? { ...g, stage } : g));
  };

  const addGuestFollowUp = (guest: Omit<GuestFollowUp, 'id'>) => {
    const newGuest: GuestFollowUp = {
      ...guest,
      id: `gfu-${Date.now()}`,
    };
    setGuestFollowUps(prev => [newGuest, ...prev]);
  };

  const togglePrayerStatus = (id: string, answeredNote?: string) => {
    setPrayerRequests(prev => prev.map(p => {
      if (p.id === id) {
        const nextStatus = p.status === 'Praying' ? 'Answered' : 'Praying';
        return {
          ...p,
          status: nextStatus,
          answeredNote: nextStatus === 'Answered' ? (answeredNote || 'God answered this prayer request with praise!') : undefined,
        };
      }
      return p;
    }));
  };

  const addPrayerRequest = (request: Omit<GeneralPrayerRequest, 'id' | 'dateSubmitted' | 'status'>) => {
    const newPrayer: GeneralPrayerRequest = {
      ...request,
      id: `gpr-${Date.now()}`,
      dateSubmitted: new Date().toISOString().split('T')[0],
      status: 'Praying',
    };
    setPrayerRequests(prev => [newPrayer, ...prev]);
  };

  const resetToDemoData = () => {
    setMembers(INITIAL_MEMBERS);
    setHouseholds(INITIAL_HOUSEHOLDS);
    setDonations(INITIAL_DONATIONS);
    setGroups(INITIAL_GROUPS);
    setEvents(INITIAL_EVENTS);
    setCheckIns(INITIAL_CHECKINS);
    setGuestFollowUps(INITIAL_GUEST_FOLLOWUPS);
    setPrayerRequests(INITIAL_PRAYER_REQUESTS);
    localStorage.clear();
  };

  return (
    <ChurchContext.Provider
      value={{
        members,
        households,
        donations,
        groups,
        events,
        checkIns,
        guestFollowUps,
        prayerRequests,
        activeCampus,
        setActiveCampus,
        addMember,
        updateMember,
        deleteMember,
        addPastoralNote,
        addDonation,
        addGroup,
        updateGroup,
        addGroupDiscussion,
        addGroupPrayerRequest,
        toggleGroupPrayerAnswered,
        addEvent,
        assignVolunteer,
        removeVolunteer,
        toggleEventRsvp,
        checkInChild,
        checkOutChild,
        updateGuestStage,
        addGuestFollowUp,
        togglePrayerStatus,
        addPrayerRequest,
        resetToDemoData,
      }}
    >
      {children}
    </ChurchContext.Provider>
  );
};

export const useChurch = () => {
  const context = useContext(ChurchContext);
  if (!context) {
    throw new Error('useChurch must be used within a ChurchProvider');
  }
  return context;
};
