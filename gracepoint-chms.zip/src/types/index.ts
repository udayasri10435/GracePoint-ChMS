export type MembershipStatus = 'Member' | 'Regular Attender' | 'First-Time Visitor' | 'Inactive';
export type BaptismStatus = 'Baptized' | 'Not Baptized' | 'Scheduled';
export type HouseholdRole = 'Head' | 'Spouse' | 'Child' | 'Individual';
export type Campus = 'Main Sanctuary' | 'North Campus' | 'Online Campus';

export interface PastoralNote {
  id: string;
  date: string;
  author: string;
  category: 'Spiritual Milestone' | 'Hospital Visit' | 'General Care' | 'Prayer Need' | 'Discipleship';
  content: string;
  isConfidential: boolean;
}

export interface Member {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  householdId: string;
  householdName: string;
  householdRole: HouseholdRole;
  membershipStatus: MembershipStatus;
  baptismStatus: BaptismStatus;
  baptismDate?: string;
  membershipDate?: string;
  birthday: string;
  campus: Campus;
  groups: string[]; // group IDs
  volunteerTeams: string[];
  avatarInitial?: string;
  allergies?: string;
  gradeOrAge?: string;
  pastoralNotes: PastoralNote[];
  tags: string[];
  createdAt: string;
}

export interface Household {
  id: string;
  name: string;
  primaryAddress: string;
  emergencyContact: {
    name: string;
    phone: string;
    relationship: string;
  };
  memberIds: string[];
}

export type FundCategory = 
  | 'Tithe & General'
  | 'Missions & Outreach'
  | 'Building Campaign'
  | 'Youth & Camp'
  | 'Benevolence Fund';

export type PaymentMethod = 'Card' | 'ACH Transfer' | 'Cash' | 'Check';

export interface Donation {
  id: string;
  memberId: string;
  memberName: string;
  memberEmail?: string;
  amount: number;
  fund: FundCategory;
  date: string;
  method: PaymentMethod;
  checkNumber?: string;
  recurring: boolean;
  frequency?: 'One-time' | 'Weekly' | 'Bi-weekly' | 'Monthly';
  receiptNumber: string;
  memo?: string;
  status: 'Completed' | 'Processing';
}

export interface GroupDiscussion {
  id: string;
  author: string;
  date: string;
  content: string;
}

export interface GroupPrayerRequest {
  id: string;
  author: string;
  request: string;
  date: string;
  isAnswered: boolean;
}

export interface ChurchGroup {
  id: string;
  name: string;
  category: 'Life Group' | 'Bible Study' | 'Ministry Team' | 'Youth' | 'Men' | 'Women' | 'Prayer';
  leaderId: string;
  leaderName: string;
  meetingSchedule: string;
  location: string;
  description: string;
  memberIds: string[];
  capacity: number;
  discussions: GroupDiscussion[];
  prayerRequests: GroupPrayerRequest[];
}

export interface VolunteerRoleSlot {
  id: string;
  roleTitle: string;
  team: string;
  countRequired: number;
  assignedMemberIds: string[];
}

export interface ChurchEvent {
  id: string;
  title: string;
  type: 'Sunday Service' | 'Midweek Service' | 'Special Event' | 'Community Outreach' | 'Youth Gathering' | 'Volunteer Training';
  date: string;
  startTime: string;
  endTime: string;
  campus: Campus;
  locationRoom: string;
  description: string;
  capacity?: number;
  rsvpMemberIds: string[];
  volunteerSlots: VolunteerRoleSlot[];
}

export interface CheckInRecord {
  id: string;
  childId: string;
  childName: string;
  householdId: string;
  parentName: string;
  parentPhone: string;
  serviceId: string;
  serviceName: string;
  roomName: string;
  securityCode: string; // e.g. "G-482"
  checkInTime: string;
  checkOutTime?: string;
  status: 'Checked In' | 'Picked Up';
  allergies?: string;
  medicalNotes?: string;
}

export interface GuestFollowUp {
  id: string;
  guestName: string;
  phone: string;
  email: string;
  firstVisitDate: string;
  assignedLeader: string;
  stage: 'New Visitor' | 'Welcome Contact' | 'Pastoral Connect' | 'Invited to Group' | 'Integrated Member';
  notes: string;
  prayerNeeds?: string;
}

export interface GeneralPrayerRequest {
  id: string;
  requesterName: string;
  requestText: string;
  dateSubmitted: string;
  status: 'Praying' | 'Answered';
  isPublic: boolean;
  answeredNote?: string;
}
