import React, { useState } from 'react';
import { useChurch } from '../../context/ChurchContext';
import { MembershipStatus, BaptismStatus, HouseholdRole, Campus } from '../../types';
import { X, UserPlus, Home } from 'lucide-react';

interface AddMemberModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AddMemberModal: React.FC<AddMemberModalProps> = ({ isOpen, onClose }) => {
  const { households, addMember } = useChurch();

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [birthday, setBirthday] = useState('1995-01-01');
  const [householdChoice, setHouseholdChoice] = useState<string>(households[0]?.id || 'new');
  const [newHouseholdName, setNewHouseholdName] = useState('');
  const [householdRole, setHouseholdRole] = useState<HouseholdRole>('Individual');
  const [membershipStatus, setMembershipStatus] = useState<MembershipStatus>('Regular Attender');
  const [baptismStatus, setBaptismStatus] = useState<BaptismStatus>('Not Baptized');
  const [baptismDate, setBaptismDate] = useState('');
  const [campus, setCampus] = useState<Campus>('Main Sanctuary');
  const [allergies, setAllergies] = useState('');
  const [volunteerTeam, setVolunteerTeam] = useState('');
  const [tagsInput, setTagsInput] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName.trim() || !lastName.trim()) return;

    let selectedHouseholdId = householdChoice;
    let selectedHouseholdName = '';

    if (householdChoice === 'new') {
      selectedHouseholdId = `hh-${Date.now()}`;
      selectedHouseholdName = newHouseholdName.trim() || `${lastName} Family`;
    } else {
      const foundHh = households.find(h => h.id === householdChoice);
      selectedHouseholdName = foundHh ? foundHh.name : `${lastName} Family`;
    }

    const tags = tagsInput
      .split(',')
      .map(t => t.trim())
      .filter(Boolean);

    const volunteerTeams = volunteerTeam ? [volunteerTeam] : [];

    addMember({
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      email: email.trim(),
      phone: phone.trim(),
      address: address.trim() || 'Springfield',
      householdId: selectedHouseholdId,
      householdName: selectedHouseholdName,
      householdRole,
      membershipStatus,
      baptismStatus,
      baptismDate: baptismDate || undefined,
      birthday,
      campus,
      groups: [],
      volunteerTeams,
      allergies: allergies.trim() || undefined,
      tags,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl overflow-hidden my-8">
        
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-600 text-white flex items-center justify-center">
              <UserPlus className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display text-lg font-bold text-white">Enroll New Member</h3>
              <p className="text-xs text-slate-300">Add an individual to the church directory and household unit</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto text-xs">
          
          {/* Name */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">First Name *</label>
              <input
                type="text"
                required
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                placeholder="e.g. John"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Last Name *</label>
              <input
                type="text"
                required
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                placeholder="e.g. Adams"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500"
              />
            </div>
          </div>

          {/* Contact Details */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="john@example.com"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Mobile Phone</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="(555) 000-0000"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500"
              />
            </div>
          </div>

          {/* Street Address */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Home Street Address</label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="e.g. 123 Blessing Way, Springfield"
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500"
            />
          </div>

          {/* Household Assignment */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 space-y-3">
            <div className="flex items-center gap-2 font-semibold text-slate-800">
              <Home className="w-3.5 h-3.5 text-amber-700" />
              <span>Family & Household Association</span>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-600 mb-1">Assign to Household</label>
                <select
                  value={householdChoice}
                  onChange={(e) => setHouseholdChoice(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-lg p-2"
                >
                  <option value="new">+ Create New Family Unit</option>
                  {households.map(hh => (
                    <option key={hh.id} value={hh.id}>{hh.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-600 mb-1">Household Role</label>
                <select
                  value={householdRole}
                  onChange={(e) => setHouseholdRole(e.target.value as HouseholdRole)}
                  className="w-full bg-white border border-slate-200 rounded-lg p-2"
                >
                  <option value="Head">Head of Household</option>
                  <option value="Spouse">Spouse</option>
                  <option value="Child">Child (GraceKids / Youth)</option>
                  <option value="Individual">Individual Adult</option>
                </select>
              </div>
            </div>

            {householdChoice === 'new' && (
              <div>
                <label className="block text-slate-600 mb-1">New Household / Family Name</label>
                <input
                  type="text"
                  value={newHouseholdName}
                  onChange={(e) => setNewHouseholdName(e.target.value)}
                  placeholder={lastName ? `${lastName} Family` : 'e.g. Miller Family'}
                  className="w-full bg-white border border-slate-200 rounded-lg p-2"
                />
              </div>
            )}
          </div>

          {/* Church Status & Campus */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Membership Status</label>
              <select
                value={membershipStatus}
                onChange={(e) => setMembershipStatus(e.target.value as MembershipStatus)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
              >
                <option value="Member">Official Member</option>
                <option value="Regular Attender">Regular Attender</option>
                <option value="First-Time Visitor">First-Time Visitor</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Baptism Status</label>
              <select
                value={baptismStatus}
                onChange={(e) => setBaptismStatus(e.target.value as BaptismStatus)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
              >
                <option value="Baptized">Baptized</option>
                <option value="Scheduled">Scheduled for Baptism</option>
                <option value="Not Baptized">Not Baptized</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Campus</label>
              <select
                value={campus}
                onChange={(e) => setCampus(e.target.value as Campus)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
              >
                <option value="Main Sanctuary">Main Sanctuary</option>
                <option value="North Campus">North Campus</option>
                <option value="Online Campus">Online Campus</option>
              </select>
            </div>
          </div>

          {/* Medical / Allergies (Especially for Kids Check-in) */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Allergies & Medical Alerts (Printed on Check-in Badges)
            </label>
            <input
              type="text"
              value={allergies}
              onChange={(e) => setAllergies(e.target.value)}
              placeholder="e.g. Peanut allergy, Asthma inhaler in backpack, Dairy sensitive"
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500"
            />
          </div>

          {/* Volunteer Ministry Team */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Volunteer Team Interest</label>
              <select
                value={volunteerTeam}
                onChange={(e) => setVolunteerTeam(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
              >
                <option value="">None / Not Currently Serving</option>
                <option value="Ushers & Greeters">Ushers & Hospitality</option>
                <option value="Worship Team">Worship Team & Choir</option>
                <option value="Audio & Live Stream Tech">Audio & Tech Production</option>
                <option value="Kids Ministry">GraceKids Children's Ministry</option>
                <option value="Prayer Team">Intercessory Prayer Team</option>
                <option value="Safety & Security Watch">Safety & Security Watch</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Tags (comma separated)</label>
              <input
                type="text"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                placeholder="e.g. Young Adult, Musician, Tither"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              Save Member
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
