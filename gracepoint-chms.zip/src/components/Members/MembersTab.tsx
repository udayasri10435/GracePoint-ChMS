import React, { useState, useMemo } from 'react';
import { useChurch } from '../../context/ChurchContext';
import { Member, HouseholdRole, MembershipStatus, Campus } from '../../types';
import { 
  Search, 
  Plus, 
  Download, 
  Mail, 
  Phone, 
  MapPin, 
  Home, 
  Heart, 
  Calendar, 
  Tag, 
  ChevronRight, 
  Edit3, 
  Trash2, 
  Sparkles,
  ShieldAlert,
  FileText,
  X
} from 'lucide-react';

interface MembersTabProps {
  onOpenAddModal: () => void;
  onGenerateTaxStatement: (member: Member) => void;
}

export const MembersTab: React.FC<MembersTabProps> = ({ 
  onOpenAddModal,
  onGenerateTaxStatement
}) => {
  const { 
    members, 
    households, 
    donations, 
    groups, 
    updateMember, 
    deleteMember, 
    addPastoralNote,
    activeCampus 
  } = useChurch();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [campusFilter, setCampusFilter] = useState<string>('all');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'individual' | 'household'>('individual');
  
  // Selected Member for Profile Drawer
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);

  // New pastoral note input state
  const [showNoteForm, setShowNoteForm] = useState(false);
  const [noteCategory, setNoteCategory] = useState<'General Care' | 'Spiritual Milestone' | 'Hospital Visit' | 'Prayer Need' | 'Discipleship'>('General Care');
  const [noteContent, setNoteContent] = useState('');
  const [noteAuthor, setNoteAuthor] = useState('Pastor David Sterling');

  // Filter members
  const filteredMembers = useMemo(() => {
    return members.filter(m => {
      // Global campus filter from context if active, plus local filter
      if (activeCampus !== 'All Campuses' && m.campus !== activeCampus) return false;
      if (campusFilter !== 'all' && m.campus !== campusFilter) return false;
      if (statusFilter !== 'all' && m.membershipStatus !== statusFilter) return false;
      if (roleFilter !== 'all') {
        if (roleFilter === 'Child' && m.householdRole !== 'Child') return false;
        if (roleFilter === 'Adult' && m.householdRole === 'Child') return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const fullName = `${m.firstName} ${m.lastName}`.toLowerCase();
        const matchesName = fullName.includes(q);
        const matchesEmail = m.email.toLowerCase().includes(q);
        const matchesPhone = m.phone.includes(q);
        const matchesTags = m.tags.some(t => t.toLowerCase().includes(q));
        const matchesHousehold = m.householdName.toLowerCase().includes(q);
        return matchesName || matchesEmail || matchesPhone || matchesTags || matchesHousehold;
      }
      return true;
    });
  }, [members, activeCampus, campusFilter, statusFilter, roleFilter, searchQuery]);

  // Export to CSV
  const handleExportCSV = () => {
    const headers = ['First Name', 'Last Name', 'Email', 'Phone', 'Address', 'Household', 'Role', 'Status', 'Baptism', 'Campus', 'Tags'];
    const rows = filteredMembers.map(m => [
      `"${m.firstName}"`,
      `"${m.lastName}"`,
      `"${m.email}"`,
      `"${m.phone}"`,
      `"${m.address.replace(/"/g, '""')}"`,
      `"${m.householdName}"`,
      `"${m.householdRole}"`,
      `"${m.membershipStatus}"`,
      `"${m.baptismStatus}"`,
      `"${m.campus}"`,
      `"${m.tags.join(', ')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `gracepoint_members_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMember || !noteContent.trim()) return;

    addPastoralNote(selectedMember.id, {
      date: new Date().toISOString().split('T')[0],
      author: noteAuthor,
      category: noteCategory,
      content: noteContent.trim(),
      isConfidential: false,
    });

    // Update selected member view locally
    const updated = members.find(m => m.id === selectedMember.id);
    if (updated) {
      setSelectedMember({
        ...updated,
        pastoralNotes: [
          {
            id: `note-${Date.now()}`,
            date: new Date().toISOString().split('T')[0],
            author: noteAuthor,
            category: noteCategory,
            content: noteContent.trim(),
            isConfidential: false,
          },
          ...updated.pastoralNotes
        ]
      });
    }

    setNoteContent('');
    setShowNoteForm(false);
  };

  // Member giving data
  const memberDonations = useMemo(() => {
    if (!selectedMember) return [];
    return donations.filter(d => d.memberId === selectedMember.id);
  }, [donations, selectedMember]);

  const memberGivingTotal = memberDonations.reduce((sum, d) => sum + d.amount, 0);

  return (
    <div className="space-y-6">
      
      {/* Top Header & Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h2 className="font-display text-2xl font-bold text-slate-900">Congregation Directory</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {filteredMembers.length} individuals enrolled across {households.length} households
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {/* View mode toggle */}
          <div className="flex items-center p-1 bg-slate-100 rounded-lg text-xs font-medium">
            <button
              onClick={() => setViewMode('individual')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                viewMode === 'individual' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Individuals
            </button>
            <button
              onClick={() => setViewMode('household')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                viewMode === 'household' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Households
            </button>
          </div>

          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-xs cursor-pointer"
            title="Download CSV directory"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>

          <button
            onClick={onOpenAddModal}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Member</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          
          {/* Search bar */}
          <div className="md:col-span-2 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by name, email, phone, household, or tag..."
              className="w-full pl-9 pr-3 py-2 text-xs text-slate-900 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-600"
            />
          </div>

          {/* Membership Status Filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full py-2 px-3 text-xs text-slate-700 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-600 cursor-pointer"
            >
              <option value="all">All Membership Statuses</option>
              <option value="Member">Official Member</option>
              <option value="Regular Attender">Regular Attender</option>
              <option value="First-Time Visitor">First-Time Visitor</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>

          {/* Age Group Filter */}
          <div>
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="w-full py-2 px-3 text-xs text-slate-700 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-600 cursor-pointer"
            >
              <option value="all">All Age Groups</option>
              <option value="Adult">Adults (Head/Spouse/Indiv)</option>
              <option value="Child">Children & Youth</option>
            </select>
          </div>

        </div>
      </div>

      {/* Roster View: Individuals or Households */}
      {viewMode === 'individual' ? (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-3 px-4">Member Name</th>
                  <th className="py-3 px-4">Status & Baptism</th>
                  <th className="py-3 px-4">Household</th>
                  <th className="py-3 px-4">Contact</th>
                  <th className="py-3 px-4">Campus & Groups</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredMembers.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-500">
                      No congregation members match your current filter criteria.
                    </td>
                  </tr>
                ) : (
                  filteredMembers.map((m) => {
                    const memberGroupCount = m.groups.length;
                    return (
                      <tr 
                        key={m.id} 
                        onClick={() => setSelectedMember(m)}
                        className="hover:bg-amber-50/40 transition-colors cursor-pointer group"
                      >
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold text-xs shrink-0">
                              {m.avatarInitial || m.firstName[0]}
                            </div>
                            <div>
                              <div className="font-semibold text-slate-900 group-hover:text-amber-900 transition-colors">
                                {m.firstName} {m.lastName}
                              </div>
                              <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                                <span>{m.householdRole}</span>
                                {m.allergies && (
                                  <>
                                    <span>·</span>
                                    <span className="text-amber-700 font-medium flex items-center gap-0.5">
                                      <ShieldAlert className="w-3 h-3" /> Allergy
                                    </span>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>
                        </td>

                        <td className="py-3 px-4">
                          <div className="text-slate-800 font-medium">{m.membershipStatus}</div>
                          <div className="text-[11px] text-slate-500">
                            {m.baptismStatus === 'Baptized' 
                              ? `Baptized (${m.baptismDate?.split('-')[0] || 'Yes'})`
                              : m.baptismStatus === 'Scheduled' 
                              ? 'Baptism Scheduled' 
                              : 'Not Baptized'}
                          </div>
                        </td>

                        <td className="py-3 px-4">
                          <div className="font-medium text-slate-800 flex items-center gap-1.5">
                            <Home className="w-3.5 h-3.5 text-slate-400" />
                            <span>{m.householdName}</span>
                          </div>
                          <div className="text-[11px] text-slate-400 truncate max-w-[180px]">{m.address}</div>
                        </td>

                        <td className="py-3 px-4">
                          {m.email && (
                            <div className="text-slate-700 flex items-center gap-1 truncate max-w-[200px]">
                              <Mail className="w-3 h-3 text-slate-400 shrink-0" />
                              <span className="truncate">{m.email}</span>
                            </div>
                          )}
                          {m.phone && (
                            <div className="text-slate-500 text-[11px] flex items-center gap-1 mt-0.5">
                              <Phone className="w-3 h-3 text-slate-400 shrink-0" />
                              <span>{m.phone}</span>
                            </div>
                          )}
                          {!m.email && !m.phone && (
                            <span className="text-slate-400 italic text-[11px]">Via parent contact</span>
                          )}
                        </td>

                        <td className="py-3 px-4">
                          <div className="text-slate-700 font-medium">{m.campus}</div>
                          <div className="text-[11px] text-slate-500">
                            {memberGroupCount > 0 ? `${memberGroupCount} Group${memberGroupCount > 1 ? 's' : ''}` : 'No Groups'}
                            {m.volunteerTeams.length > 0 && ` · ${m.volunteerTeams[0]}`}
                          </div>
                        </td>

                        <td className="py-3 px-4 text-right">
                          <div className="inline-flex items-center gap-1">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedMember(m);
                              }}
                              className="px-2.5 py-1 text-slate-700 bg-slate-100 hover:bg-slate-200 rounded font-medium transition-colors"
                            >
                              Profile
                            </button>
                            <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-amber-800 transition-colors" />
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Household View */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {households.map((hh) => {
            const familyMembers = members.filter(m => hh.memberIds.includes(m.id));
            const head = familyMembers.find(m => m.householdRole === 'Head');
            return (
              <div 
                key={hh.id} 
                className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs hover:border-amber-300 transition-colors"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-800 flex items-center justify-center">
                      <Home className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-900 text-sm">{hh.name}</h4>
                      <span className="text-[11px] text-slate-500">{familyMembers.length} Family Members</span>
                    </div>
                  </div>
                </div>

                <div className="text-xs text-slate-500 space-y-1 mb-4 pb-3 border-b border-slate-100">
                  <div className="flex items-start gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 mt-0.5 shrink-0" />
                    <span>{hh.primaryAddress}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>Emergency Contact: {hh.emergencyContact.name} ({hh.emergencyContact.phone})</span>
                  </div>
                </div>

                <div>
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-2">
                    Family Roster
                  </span>
                  <div className="space-y-1.5">
                    {familyMembers.map((fm) => (
                      <div 
                        key={fm.id}
                        onClick={() => setSelectedMember(fm)}
                        className="flex items-center justify-between p-2 rounded bg-slate-50 hover:bg-amber-50 cursor-pointer transition-colors text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-slate-300 text-slate-700 flex items-center justify-center font-bold text-[10px]">
                            {fm.firstName[0]}
                          </span>
                          <span className="font-medium text-slate-800">{fm.firstName} {fm.lastName}</span>
                        </div>
                        <span className="text-[11px] text-slate-500">{fm.householdRole}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Member Profile Drawer / Modal */}
      {selectedMember && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/50 backdrop-blur-xs flex justify-end">
          <div className="w-full max-w-2xl bg-white h-full shadow-2xl overflow-y-auto flex flex-col">
            
            {/* Drawer Header */}
            <div className="p-6 bg-slate-900 text-white relative">
              <button
                onClick={() => setSelectedMember(null)}
                className="absolute top-5 right-5 p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-amber-600 text-white flex items-center justify-center font-display text-2xl font-bold shadow-md">
                  {selectedMember.avatarInitial || selectedMember.firstName[0]}
                </div>
                <div>
                  <div className="flex items-center gap-2 text-xs text-amber-400 font-semibold mb-1">
                    <span>{selectedMember.membershipStatus}</span>
                    <span>·</span>
                    <span>{selectedMember.householdRole}</span>
                  </div>
                  <h3 className="font-display text-2xl font-bold text-white">
                    {selectedMember.firstName} {selectedMember.lastName}
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5">{selectedMember.campus}</p>
                </div>
              </div>
            </div>

            {/* Drawer Body */}
            <div className="p-6 space-y-6 flex-1">
              
              {/* Quick Action Ribbon */}
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => onGenerateTaxStatement(selectedMember)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg transition-colors cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5 text-amber-700" />
                  <span>Contribution Tax Statement</span>
                </button>
                <button
                  onClick={() => setShowNoteForm(!showNoteForm)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Pastoral Note</span>
                </button>
              </div>

              {/* Add Pastoral Note Form Collapse */}
              {showNoteForm && (
                <form onSubmit={handleAddNote} className="bg-amber-50/70 border border-amber-200 rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-950">New Pastoral Care Note</span>
                    <button 
                      type="button" 
                      onClick={() => setShowNoteForm(false)} 
                      className="text-xs text-slate-500 hover:text-slate-800"
                    >
                      Cancel
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <label className="block text-slate-600 mb-1 font-medium">Category</label>
                      <select
                        value={noteCategory}
                        onChange={(e) => setNoteCategory(e.target.value as any)}
                        className="w-full bg-white border border-slate-200 rounded p-1.5"
                      >
                        <option value="General Care">General Care</option>
                        <option value="Spiritual Milestone">Spiritual Milestone</option>
                        <option value="Hospital Visit">Hospital Visit</option>
                        <option value="Prayer Need">Prayer Need</option>
                        <option value="Discipleship">Discipleship</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-slate-600 mb-1 font-medium">Minister / Author</label>
                      <input
                        type="text"
                        value={noteAuthor}
                        onChange={(e) => setNoteAuthor(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded p-1.5"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1 font-medium text-xs">Care Observation & Prayer Details</label>
                    <textarea
                      rows={2}
                      value={noteContent}
                      onChange={(e) => setNoteContent(e.target.value)}
                      placeholder="Enter pastoral counseling summary or prayer notes..."
                      className="w-full bg-white border border-slate-200 rounded p-2 text-xs focus:ring-1 focus:ring-amber-500"
                      required
                    />
                  </div>
                  <div className="text-right">
                    <button
                      type="submit"
                      className="px-3 py-1.5 bg-amber-800 hover:bg-amber-900 text-white font-semibold text-xs rounded transition-colors"
                    >
                      Save Note to Profile
                    </button>
                  </div>
                </form>
              )}

              {/* Contact Information & Demographics */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-2 text-xs">
                  <h4 className="font-semibold text-slate-900 pb-1 border-b border-slate-200 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-slate-500" /> Contact Info
                  </h4>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Email</span>
                    <span className="font-medium text-slate-800">{selectedMember.email || 'None on record'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Phone</span>
                    <span className="font-medium text-slate-800">{selectedMember.phone || 'None on record'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Primary Address</span>
                    <span className="font-medium text-slate-800">{selectedMember.address}</span>
                  </div>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-2 text-xs">
                  <h4 className="font-semibold text-slate-900 pb-1 border-b border-slate-200 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" /> Spiritual Milestones
                  </h4>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Baptism</span>
                    <span className="font-medium text-slate-800">
                      {selectedMember.baptismStatus === 'Baptized'
                        ? `Baptized on ${selectedMember.baptismDate || 'Confirmed'}`
                        : selectedMember.baptismStatus}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Membership Covenant</span>
                    <span className="font-medium text-slate-800">
                      {selectedMember.membershipDate ? `Signed ${selectedMember.membershipDate}` : 'Under Review'}
                    </span>
                  </div>
                  {selectedMember.allergies && (
                    <div>
                      <span className="text-rose-600 block text-[11px] font-semibold">Medical / Allergy Alert</span>
                      <span className="font-medium text-rose-900">{selectedMember.allergies}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Household & Family Members */}
              <div className="border border-slate-200 rounded-xl p-4">
                <h4 className="text-xs font-bold text-slate-900 mb-2 flex items-center justify-between">
                  <span>Household ({selectedMember.householdName})</span>
                  <span className="text-slate-500 font-normal">Role: {selectedMember.householdRole}</span>
                </h4>
                <div className="flex flex-wrap gap-2">
                  {members
                    .filter(m => m.householdId === selectedMember.householdId)
                    .map(fam => (
                      <button
                        key={fam.id}
                        onClick={() => setSelectedMember(fam)}
                        className={`px-3 py-1.5 text-xs rounded-lg border text-left cursor-pointer transition-colors ${
                          fam.id === selectedMember.id 
                            ? 'bg-amber-100 border-amber-300 text-amber-900 font-semibold' 
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <div>{fam.firstName} {fam.lastName}</div>
                        <div className="text-[10px] text-slate-500">{fam.householdRole}</div>
                      </button>
                    ))}
                </div>
              </div>

              {/* Giving Summary */}
              <div className="border border-slate-200 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Giving History & Contributions</h4>
                    <span className="text-[11px] text-slate-500">
                      YTD Contributions: <strong className="text-slate-900 tabular-nums">${memberGivingTotal.toFixed(2)}</strong>
                    </span>
                  </div>
                  <button
                    onClick={() => onGenerateTaxStatement(selectedMember)}
                    className="text-xs font-semibold text-amber-800 hover:text-amber-900 cursor-pointer"
                  >
                    View Statement
                  </button>
                </div>

                {memberDonations.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">No recorded donations found for this profile.</p>
                ) : (
                  <div className="divide-y divide-slate-100 text-xs">
                    {memberDonations.map(d => (
                      <div key={d.id} className="py-2 flex items-center justify-between">
                        <div>
                          <span className="font-semibold text-slate-800">${d.amount.toFixed(2)}</span>
                          <span className="text-slate-500 ml-2">· {d.fund}</span>
                          <span className="text-slate-400 ml-2 text-[11px]">({d.method})</span>
                        </div>
                        <span className="text-slate-400 text-[11px] tabular-nums">{d.date}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Pastoral Notes & Care Timeline */}
              <div className="border border-slate-200 rounded-xl p-4">
                <h4 className="text-xs font-bold text-slate-900 mb-3">
                  Pastoral Care & Discipleship Log ({selectedMember.pastoralNotes.length})
                </h4>

                {selectedMember.pastoralNotes.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">No pastoral notes recorded yet.</p>
                ) : (
                  <div className="space-y-3">
                    {selectedMember.pastoralNotes.map(n => (
                      <div key={n.id} className="p-3 bg-slate-50 rounded-lg border border-slate-100 text-xs">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-semibold text-slate-900">{n.category}</span>
                          <span className="text-[11px] text-slate-400 tabular-nums">{n.date}</span>
                        </div>
                        <p className="text-slate-700 leading-relaxed">{n.content}</p>
                        <div className="text-[10px] text-slate-400 mt-1.5">Logged by {n.author}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>

            {/* Drawer Footer */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
              <button
                onClick={() => {
                  if (window.confirm(`Delete member record for ${selectedMember.firstName} ${selectedMember.lastName}?`)) {
                    deleteMember(selectedMember.id);
                    setSelectedMember(null);
                  }
                }}
                className="text-xs text-rose-700 hover:text-rose-900 font-semibold cursor-pointer inline-flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Record</span>
              </button>

              <button
                onClick={() => setSelectedMember(null)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Close Profile
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
