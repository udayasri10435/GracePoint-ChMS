import React, { useState } from 'react';
import { useChurch } from '../../context/ChurchContext';
import { ChurchEvent, Member } from '../../types';
import { 
  Calendar, 
  Plus, 
  Clock, 
  MapPin, 
  Users, 
  UserCheck, 
  UserPlus, 
  ChevronRight, 
  X, 
  Check, 
  ShieldAlert,
  Sparkles
} from 'lucide-react';
import { CreateEventModal } from './CreateEventModal';

export const EventsTab: React.FC = () => {
  const { 
    events, 
    members, 
    assignVolunteer, 
    removeVolunteer, 
    toggleEventRsvp, 
    activeCampus 
  } = useChurch();

  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [selectedEvent, setSelectedEvent] = useState<ChurchEvent | null>(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  // Volunteer assigning state
  const [activeSlotToAssign, setActiveSlotToAssign] = useState<string | null>(null);
  const [selectedVolunteerMemberId, setSelectedVolunteerMemberId] = useState<string>('');

  const filteredEvents = events.filter(e => {
    if (activeCampus !== 'All Campuses' && e.campus !== activeCampus) return false;
    if (typeFilter !== 'all' && e.type !== typeFilter) return false;
    return true;
  });

  const handleConfirmVolunteerAssign = (slotId: string) => {
    if (!selectedEvent || !selectedVolunteerMemberId) return;

    assignVolunteer(selectedEvent.id, slotId, selectedVolunteerMemberId);

    // Update local modal state
    setSelectedEvent(prev => {
      if (!prev) return null;
      return {
        ...prev,
        volunteerSlots: prev.volunteerSlots.map(s => {
          if (s.id === slotId && !s.assignedMemberIds.includes(selectedVolunteerMemberId)) {
            return {
              ...s,
              assignedMemberIds: [...s.assignedMemberIds, selectedVolunteerMemberId]
            };
          }
          return s;
        })
      };
    });

    setActiveSlotToAssign(null);
    setSelectedVolunteerMemberId('');
  };

  const handleRemoveAssignedVolunteer = (slotId: string, memberId: string) => {
    if (!selectedEvent) return;

    removeVolunteer(selectedEvent.id, slotId, memberId);

    setSelectedEvent(prev => {
      if (!prev) return null;
      return {
        ...prev,
        volunteerSlots: prev.volunteerSlots.map(s => {
          if (s.id === slotId) {
            return {
              ...s,
              assignedMemberIds: s.assignedMemberIds.filter(id => id !== memberId)
            };
          }
          return s;
        })
      };
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h2 className="font-display text-2xl font-bold text-slate-900">Events & Volunteer Rosters</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Worship services, community outreaches, ministry assignments, and volunteer scheduling
          </p>
        </div>

        <button
          onClick={() => setIsCreateOpen(true)}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Schedule Service / Event</span>
        </button>
      </div>

      {/* Segmented Filter */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 border-b border-slate-100 text-xs">
        {[
          { id: 'all', label: 'All Services & Events' },
          { id: 'Sunday Service', label: 'Sunday Services' },
          { id: 'Midweek Service', label: 'Midweek Gatherings' },
          { id: 'Community Outreach', label: 'Outreach & Missions' },
          { id: 'Youth Gathering', label: 'Youth Gatherings' },
        ].map(filter => (
          <button
            key={filter.id}
            onClick={() => setTypeFilter(filter.id)}
            className={`px-3 py-1.5 font-medium rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
              typeFilter === filter.id
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
            }`}
          >
            {filter.label}
          </button>
        ))}
      </div>

      {/* Events List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredEvents.map(evt => {
          const totalSlotsRequired = evt.volunteerSlots.reduce((sum, s) => sum + s.countRequired, 0);
          const totalSlotsFilled = evt.volunteerSlots.reduce((sum, s) => sum + s.assignedMemberIds.length, 0);
          const isFullCoverage = totalSlotsFilled >= totalSlotsRequired && totalSlotsRequired > 0;

          return (
            <div
              key={evt.id}
              onClick={() => setSelectedEvent(evt)}
              className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs hover:border-amber-300 transition-all cursor-pointer flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-semibold text-amber-800 bg-amber-50 px-2 py-0.5 rounded">
                    {evt.type}
                  </span>
                  <span className="text-[11px] text-slate-500 font-medium">
                    {evt.campus}
                  </span>
                </div>

                <h3 className="font-display text-lg font-bold text-slate-900 group-hover:text-amber-900 transition-colors">
                  {evt.title}
                </h3>

                <p className="text-xs text-slate-600 line-clamp-2 mt-1 mb-4 leading-relaxed">
                  {evt.description}
                </p>

                <div className="space-y-1.5 text-xs text-slate-500 mb-4 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="font-semibold text-slate-800">{evt.date}</span>
                    <span>·</span>
                    <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{evt.startTime} - {evt.endTime}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{evt.locationRoom}</span>
                  </div>
                </div>
              </div>

              <div>
                {/* Volunteer Roster Status Indicator */}
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 mb-3 text-xs">
                  <div className="flex items-center justify-between font-medium mb-1.5">
                    <span className="text-slate-700 flex items-center gap-1.5">
                      <UserCheck className="w-3.5 h-3.5 text-slate-500" />
                      <span>Volunteer Team Coverage</span>
                    </span>
                    <span className={`text-[11px] font-semibold px-1.5 py-0.2 rounded ${
                      isFullCoverage ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-900'
                    }`}>
                      {totalSlotsFilled} / {totalSlotsRequired} Assigned
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-1 mt-1">
                    {evt.volunteerSlots.map(slot => (
                      <span
                        key={slot.id}
                        className={`text-[10px] px-2 py-0.5 rounded border ${
                          slot.assignedMemberIds.length >= slot.countRequired
                            ? 'bg-white text-slate-700 border-slate-200'
                            : 'bg-amber-50 text-amber-900 border-amber-200 font-medium'
                        }`}
                      >
                        {slot.roleTitle} ({slot.assignedMemberIds.length}/{slot.countRequired})
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                  <span>{evt.rsvpMemberIds.length} Congregants Registered</span>
                  <span className="text-amber-800 font-semibold group-hover:translate-x-0.5 transition-transform inline-flex items-center">
                    Manage Roster <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Event & Volunteer Management Drawer */}
      {selectedEvent && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex justify-end">
          <div className="w-full max-w-2xl bg-white h-full shadow-2xl overflow-y-auto flex flex-col">
            
            {/* Drawer Header */}
            <div className="p-6 bg-slate-900 text-white relative">
              <button
                onClick={() => setSelectedEvent(null)}
                className="absolute top-5 right-5 p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2 text-xs text-amber-400 font-semibold uppercase tracking-wider mb-1">
                <span>{selectedEvent.type}</span>
                <span>·</span>
                <span>{selectedEvent.campus}</span>
              </div>
              <h3 className="font-display text-2xl font-bold">{selectedEvent.title}</h3>
              <div className="flex flex-wrap gap-4 text-xs text-slate-300 mt-2">
                <span className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5 text-amber-400" /> {selectedEvent.date}</span>
                <span className="flex items-center gap-1.5"><Clock className="w-3.5 h-3.5 text-amber-400" /> {selectedEvent.startTime} - {selectedEvent.endTime}</span>
                <span className="flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5 text-amber-400" /> {selectedEvent.locationRoom}</span>
              </div>
            </div>

            {/* Drawer Body */}
            <div className="p-6 space-y-6 flex-1 text-xs">
              
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <h4 className="font-semibold text-slate-900 mb-1">Service Overview & Notes</h4>
                <p className="text-slate-600 leading-relaxed">{selectedEvent.description}</p>
              </div>

              {/* Volunteer Roster Management */}
              <div className="border border-slate-200 rounded-xl p-4 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h4 className="font-bold text-slate-900">Volunteer Serving Team Roster</h4>
                    <p className="text-[11px] text-slate-500">Assign trained congregation members to service positions</p>
                  </div>
                </div>

                <div className="space-y-3">
                  {selectedEvent.volunteerSlots.map(slot => {
                    const isSlotFull = slot.assignedMemberIds.length >= slot.countRequired;
                    const isAssigningThisSlot = activeSlotToAssign === slot.id;

                    return (
                      <div key={slot.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="font-semibold text-slate-900 text-xs">{slot.roleTitle}</span>
                            <span className="text-slate-400 ml-2 text-[11px]">({slot.team})</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                              isSlotFull ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-900'
                            }`}>
                              {slot.assignedMemberIds.length} of {slot.countRequired} Confirmed
                            </span>

                            {!isSlotFull && (
                              <button
                                onClick={() => setActiveSlotToAssign(isAssigningThisSlot ? null : slot.id)}
                                className="px-2 py-1 text-[11px] font-semibold text-slate-700 hover:text-slate-900 bg-white border border-slate-200 rounded hover:bg-slate-100 cursor-pointer"
                              >
                                {isAssigningThisSlot ? 'Cancel' : '+ Assign Member'}
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Assign dropdown */}
                        {isAssigningThisSlot && (
                          <div className="p-2.5 bg-amber-50/70 border border-amber-200 rounded-lg flex gap-2 items-center">
                            <select
                              value={selectedVolunteerMemberId}
                              onChange={(e) => setSelectedVolunteerMemberId(e.target.value)}
                              className="flex-1 bg-white border border-amber-300 rounded p-1.5 text-xs text-slate-800"
                            >
                              <option value="">Select church member to assign...</option>
                              {members
                                .filter(m => !slot.assignedMemberIds.includes(m.id))
                                .map(m => (
                                  <option key={m.id} value={m.id}>
                                    {m.firstName} {m.lastName} ({m.membershipStatus} - {m.volunteerTeams.join(', ') || 'Available'})
                                  </option>
                                ))}
                            </select>
                            <button
                              type="button"
                              onClick={() => handleConfirmVolunteerAssign(slot.id)}
                              disabled={!selectedVolunteerMemberId}
                              className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-semibold rounded text-xs cursor-pointer"
                            >
                              Confirm
                            </button>
                          </div>
                        )}

                        {/* List of currently assigned volunteers */}
                        <div className="flex flex-wrap gap-2 pt-1">
                          {slot.assignedMemberIds.length === 0 ? (
                            <span className="text-[11px] text-slate-400 italic">No volunteers assigned to this slot yet.</span>
                          ) : (
                            slot.assignedMemberIds.map(memId => {
                              const m = members.find(mem => mem.id === memId);
                              if (!m) return null;
                              return (
                                <div key={m.id} className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs">
                                  <span className="w-5 h-5 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold text-[10px]">
                                    {m.firstName[0]}
                                  </span>
                                  <span className="font-medium text-slate-800">{m.firstName} {m.lastName}</span>
                                  <button
                                    onClick={() => handleRemoveAssignedVolunteer(slot.id, m.id)}
                                    className="p-0.5 text-slate-400 hover:text-rose-700 ml-1 cursor-pointer"
                                    title="Remove volunteer"
                                  >
                                    <X className="w-3 h-3" />
                                  </button>
                                </div>
                              );
                            })
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* RSVP & Congregation Attendance List */}
              <div className="border border-slate-200 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="font-bold text-slate-900">Congregation RSVPs ({selectedEvent.rsvpMemberIds.length})</h4>
                    <span className="text-[11px] text-slate-500">Registered congregants and families attending</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {selectedEvent.rsvpMemberIds.map(mId => {
                    const m = members.find(mem => mem.id === mId);
                    if (!m) return null;
                    return (
                      <div key={m.id} className="p-2 bg-slate-50 rounded border border-slate-100 flex items-center justify-between">
                        <span className="font-medium text-slate-800">{m.firstName} {m.lastName}</span>
                        <span className="text-[10px] text-slate-400">{m.campus}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end">
              <button
                onClick={() => setSelectedEvent(null)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg cursor-pointer"
              >
                Close Roster
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Create Event Modal */}
      <CreateEventModal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
      />

    </div>
  );
};
