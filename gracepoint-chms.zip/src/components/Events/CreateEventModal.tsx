import React, { useState } from 'react';
import { useChurch } from '../../context/ChurchContext';
import { Campus, ChurchEvent, VolunteerRoleSlot } from '../../types';
import { X, Calendar, Plus, Trash2 } from 'lucide-react';

interface CreateEventModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreateEventModal: React.FC<CreateEventModalProps> = ({ isOpen, onClose }) => {
  const { addEvent } = useChurch();

  const [title, setTitle] = useState('');
  const [type, setType] = useState<ChurchEvent['type']>('Sunday Service');
  const [date, setDate] = useState('2026-10-11');
  const [startTime, setStartTime] = useState('09:00 AM');
  const [endTime, setEndTime] = useState('10:30 AM');
  const [campus, setCampus] = useState<Campus>('Main Sanctuary');
  const [locationRoom, setLocationRoom] = useState('Main Sanctuary');
  const [description, setDescription] = useState('');
  const [capacity, setCapacity] = useState(350);

  // Volunteer role slots
  const [slots, setSlots] = useState<{ id: string; roleTitle: string; team: string; countRequired: number }[]>([
    { id: '1', roleTitle: 'Front Door Greeter', team: 'Ushers & Hospitality', countRequired: 2 },
    { id: '2', roleTitle: 'Audio Engineer', team: 'Tech Production', countRequired: 1 },
    { id: '3', roleTitle: 'Nursery Lead', team: 'Kids Ministry', countRequired: 2 },
  ]);

  if (!isOpen) return null;

  const handleAddSlot = () => {
    setSlots(prev => [
      ...prev,
      { id: Date.now().toString(), roleTitle: 'Volunteer Server', team: 'General Serving', countRequired: 1 }
    ]);
  };

  const handleRemoveSlot = (id: string) => {
    setSlots(prev => prev.filter(s => s.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const formattedSlots: VolunteerRoleSlot[] = slots.map(s => ({
      id: `vs-${Date.now()}-${s.id}`,
      roleTitle: s.roleTitle,
      team: s.team,
      countRequired: s.countRequired,
      assignedMemberIds: [],
    }));

    addEvent({
      title: title.trim(),
      type,
      date,
      startTime,
      endTime,
      campus,
      locationRoom,
      description: description.trim() || 'Worship gathering and biblical discipleship.',
      capacity,
      rsvpMemberIds: [],
      volunteerSlots: formattedSlots,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl overflow-hidden my-6">
        
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-600 text-white flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display text-lg font-bold">Schedule Service or Church Event</h3>
              <p className="text-xs text-slate-300">Configure event details and volunteer service teams</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
          
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Event Title *</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Sunday Celebration Worship or Fall Outreach Night"
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Event Category</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
              >
                <option value="Sunday Service">Sunday Service</option>
                <option value="Midweek Service">Midweek Service</option>
                <option value="Special Event">Special Conference</option>
                <option value="Community Outreach">Community Outreach</option>
                <option value="Youth Gathering">Youth Gathering</option>
                <option value="Volunteer Training">Volunteer Training</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Campus</label>
              <select
                value={campus}
                onChange={(e) => setCampus(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
              >
                <option value="Main Sanctuary">Main Sanctuary</option>
                <option value="North Campus">North Campus</option>
                <option value="Online Campus">Online Campus</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Date</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Start Time</label>
              <input
                type="text"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                placeholder="09:00 AM"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">End Time</label>
              <input
                type="text"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                placeholder="10:30 AM"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Location Room</label>
              <input
                type="text"
                value={locationRoom}
                onChange={(e) => setLocationRoom(e.target.value)}
                placeholder="e.g. Main Auditorium or Fellowship Hall"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Estimated Capacity</label>
              <input
                type="number"
                value={capacity}
                onChange={(e) => setCapacity(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Description & Bulletin Notes</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Sermon series title, guest speakers, childcare availability..."
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
            />
          </div>

          {/* Volunteer Roles Template */}
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-800">Volunteer Role Requirements</span>
              <button
                type="button"
                onClick={handleAddSlot}
                className="text-[11px] font-semibold text-amber-800 hover:text-amber-900 inline-flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3 h-3" /> Add Serving Role
              </button>
            </div>

            <div className="space-y-2">
              {slots.map((s, idx) => (
                <div key={s.id} className="flex items-center gap-2 bg-white p-2 rounded-lg border border-slate-200">
                  <input
                    type="text"
                    value={s.roleTitle}
                    onChange={(e) => {
                      const updated = [...slots];
                      updated[idx].roleTitle = e.target.value;
                      setSlots(updated);
                    }}
                    placeholder="Role Title"
                    className="flex-1 bg-slate-50 border border-slate-200 rounded p-1 text-xs"
                  />
                  <input
                    type="text"
                    value={s.team}
                    onChange={(e) => {
                      const updated = [...slots];
                      updated[idx].team = e.target.value;
                      setSlots(updated);
                    }}
                    placeholder="Ministry Team"
                    className="w-36 bg-slate-50 border border-slate-200 rounded p-1 text-xs"
                  />
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={s.countRequired}
                    onChange={(e) => {
                      const updated = [...slots];
                      updated[idx].countRequired = Number(e.target.value) || 1;
                      setSlots(updated);
                    }}
                    className="w-14 bg-slate-50 border border-slate-200 rounded p-1 text-xs text-center"
                  />
                  <button
                    type="button"
                    onClick={() => handleRemoveSlot(s.id)}
                    className="p-1 text-slate-400 hover:text-rose-700 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:text-slate-800 bg-slate-100 rounded-lg font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-white bg-slate-900 hover:bg-slate-800 rounded-lg font-semibold shadow-xs cursor-pointer"
            >
              Schedule Event
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
