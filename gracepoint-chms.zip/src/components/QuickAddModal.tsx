import React from 'react';
import { X, UserPlus, HeartHandshake, Calendar, QrCode, UserCheck } from 'lucide-react';
import { ActiveTab } from './Navigation';

interface QuickAddModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddMember: () => void;
  onRecordGift: () => void;
  onLaunchKiosk: () => void;
  onNavigateTab: (tab: ActiveTab) => void;
}

export const QuickAddModal: React.FC<QuickAddModalProps> = ({
  isOpen,
  onClose,
  onAddMember,
  onRecordGift,
  onLaunchKiosk,
  onNavigateTab,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-sm w-full shadow-2xl overflow-hidden">
        
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="font-display font-bold text-sm">Quick Church Actions</div>
          <button onClick={onClose} className="text-slate-400 hover:text-white cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-2 text-xs">
          <button
            onClick={() => {
              onClose();
              onAddMember();
            }}
            className="w-full p-3 rounded-xl border border-slate-200 hover:border-amber-400 hover:bg-amber-50/50 flex items-center gap-3 text-left transition-all cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-900 flex items-center justify-center shrink-0">
              <UserPlus className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold text-slate-900 group-hover:text-amber-950">Enroll New Member</div>
              <div className="text-[11px] text-slate-500">Add to congregation directory and family unit</div>
            </div>
          </button>

          <button
            onClick={() => {
              onClose();
              onRecordGift();
            }}
            className="w-full p-3 rounded-xl border border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/50 flex items-center gap-3 text-left transition-all cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-900 flex items-center justify-center shrink-0">
              <HeartHandshake className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold text-slate-900 group-hover:text-emerald-950">Record Contribution</div>
              <div className="text-[11px] text-slate-500">Log tithe, check, cash, or pledge donation</div>
            </div>
          </button>

          <button
            onClick={() => {
              onClose();
              onLaunchKiosk();
            }}
            className="w-full p-3 rounded-xl border border-slate-200 hover:border-amber-400 hover:bg-amber-50/50 flex items-center gap-3 text-left transition-all cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-900 flex items-center justify-center shrink-0">
              <QrCode className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold text-slate-900 group-hover:text-amber-950">Launch Sunday Kiosk</div>
              <div className="text-[11px] text-slate-500">Self-service child check-in and label printing</div>
            </div>
          </button>

          <button
            onClick={() => {
              onClose();
              onNavigateTab('events');
            }}
            className="w-full p-3 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 flex items-center gap-3 text-left transition-all cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-800 flex items-center justify-center shrink-0">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold text-slate-900">Manage Volunteer Rosters</div>
              <div className="text-[11px] text-slate-500">Schedule services & assign ministry roles</div>
            </div>
          </button>

          <button
            onClick={() => {
              onClose();
              onNavigateTab('care');
            }}
            className="w-full p-3 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 flex items-center gap-3 text-left transition-all cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-800 flex items-center justify-center shrink-0">
              <UserCheck className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold text-slate-900">Visitor Follow-Up Pipeline</div>
              <div className="text-[11px] text-slate-500">Connect with guests and track integration</div>
            </div>
          </button>
        </div>

      </div>
    </div>
  );
};
