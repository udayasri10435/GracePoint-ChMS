import React, { useState } from 'react';
import { useChurch } from '../../context/ChurchContext';
import { ChurchGroup } from '../../types';
import { X, Users, Calendar, MapPin } from 'lucide-react';

interface CreateGroupModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreateGroupModal: React.FC<CreateGroupModalProps> = ({ isOpen, onClose }) => {
  const { members, addGroup } = useChurch();

  const [name, setName] = useState('');
  const [category, setCategory] = useState<ChurchGroup['category']>('Life Group');
  const [leaderId, setLeaderId] = useState(members[0]?.id || '');
  const [meetingSchedule, setMeetingSchedule] = useState('Wednesdays · 7:00 PM');
  const [location, setLocation] = useState('Church Fireside Room');
  const [description, setDescription] = useState('');
  const [capacity, setCapacity] = useState(16);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const leader = members.find(m => m.id === leaderId);
    const leaderName = leader ? `${leader.firstName} ${leader.lastName}` : 'Pastor Team';

    addGroup({
      name: name.trim(),
      category,
      leaderId,
      leaderName,
      meetingSchedule: meetingSchedule.trim(),
      location: location.trim(),
      description: description.trim() || 'Midweek community fellowship and biblical discipleship.',
      capacity: Number(capacity) || 15,
      memberIds: leaderId ? [leaderId] : [],
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-600 text-white flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display text-lg font-bold">Create Ministry or Life Group</h3>
              <p className="text-xs text-slate-300">Set up a fellowship group, Bible study, or service team</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Group Name *</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Northside Couples Fellowship"
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
              >
                <option value="Life Group">Life Group / Fellowship</option>
                <option value="Bible Study">Bible Study</option>
                <option value="Ministry Team">Ministry / Volunteer Team</option>
                <option value="Youth">Youth (Grades 6-12)</option>
                <option value="Men">Men's Ministry</option>
                <option value="Women">Women's Ministry</option>
                <option value="Prayer">Intercessory Prayer</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Group Leader *</label>
              <select
                value={leaderId}
                onChange={(e) => setLeaderId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
              >
                {members.map(m => (
                  <option key={m.id} value={m.id}>
                    {m.firstName} {m.lastName} ({m.householdRole})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Meeting Schedule</label>
              <input
                type="text"
                value={meetingSchedule}
                onChange={(e) => setMeetingSchedule(e.target.value)}
                placeholder="e.g. Thursdays · 7:00 PM"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Max Capacity</label>
              <input
                type="number"
                min="4"
                max="100"
                value={capacity}
                onChange={(e) => setCapacity(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Meeting Location</label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g. Room 104, or Member Home Address"
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Description & Study Focus</label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief description of format, study curriculum, childcare arrangements..."
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
            />
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:text-slate-800 bg-slate-100 rounded-lg font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-white bg-slate-900 hover:bg-slate-800 rounded-lg font-semibold shadow-xs"
            >
              Create Group
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
