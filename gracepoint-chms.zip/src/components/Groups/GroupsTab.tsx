import React, { useState } from 'react';
import { useChurch } from '../../context/ChurchContext';
import { ChurchGroup, Member } from '../../types';
import { 
  Users, 
  Plus, 
  MapPin, 
  Clock, 
  MessageSquare, 
  Heart, 
  CheckCircle, 
  UserPlus, 
  X, 
  ChevronRight,
  Sparkles,
  BookOpen
} from 'lucide-react';
import { CreateGroupModal } from './CreateGroupModal';

export const GroupsTab: React.FC = () => {
  const { 
    groups, 
    members, 
    updateGroup, 
    addGroupDiscussion, 
    addGroupPrayerRequest, 
    toggleGroupPrayerAnswered 
  } = useChurch();

  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [selectedGroup, setSelectedGroup] = useState<ChurchGroup | null>(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  // Group Detail interaction state
  const [newDiscussionContent, setNewDiscussionContent] = useState('');
  const [newDiscussionAuthor, setNewDiscussionAuthor] = useState('Pastor David Sterling');
  const [newPrayerText, setNewPrayerText] = useState('');
  const [newPrayerAuthor, setNewPrayerAuthor] = useState('');
  const [memberToAddId, setMemberToAddId] = useState('');

  const filteredGroups = categoryFilter === 'all'
    ? groups
    : groups.filter(g => g.category === categoryFilter);

  // Handle adding a member to group
  const handleAddMemberToGroup = () => {
    if (!selectedGroup || !memberToAddId) return;
    if (selectedGroup.memberIds.includes(memberToAddId)) return;

    const updatedMemberIds = [...selectedGroup.memberIds, memberToAddId];
    updateGroup(selectedGroup.id, { memberIds: updatedMemberIds });

    setSelectedGroup({
      ...selectedGroup,
      memberIds: updatedMemberIds,
    });
    setMemberToAddId('');
  };

  // Handle removing a member from group
  const handleRemoveMember = (memberId: string) => {
    if (!selectedGroup) return;
    const updatedMemberIds = selectedGroup.memberIds.filter(id => id !== memberId);
    updateGroup(selectedGroup.id, { memberIds: updatedMemberIds });

    setSelectedGroup({
      ...selectedGroup,
      memberIds: updatedMemberIds,
    });
  };

  // Handle posting discussion
  const handlePostDiscussion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGroup || !newDiscussionContent.trim()) return;

    addGroupDiscussion(selectedGroup.id, newDiscussionAuthor, newDiscussionContent.trim());

    setSelectedGroup({
      ...selectedGroup,
      discussions: [
        {
          id: `disc-${Date.now()}`,
          author: newDiscussionAuthor,
          date: new Date().toISOString().split('T')[0],
          content: newDiscussionContent.trim(),
        },
        ...selectedGroup.discussions,
      ],
    });

    setNewDiscussionContent('');
  };

  // Handle adding prayer request
  const handleAddPrayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGroup || !newPrayerText.trim()) return;

    const authorName = newPrayerAuthor.trim() || 'Group Member';
    addGroupPrayerRequest(selectedGroup.id, authorName, newPrayerText.trim());

    setSelectedGroup({
      ...selectedGroup,
      prayerRequests: [
        {
          id: `gpr-${Date.now()}`,
          author: authorName,
          request: newPrayerText.trim(),
          date: new Date().toISOString().split('T')[0],
          isAnswered: false,
        },
        ...selectedGroup.prayerRequests,
      ],
    });

    setNewPrayerText('');
  };

  return (
    <div className="space-y-6">
      
      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h2 className="font-display text-2xl font-bold text-slate-900">Groups & Ministries</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Community life groups, discipleship Bible studies, youth circles, and volunteer serving teams
          </p>
        </div>

        <button
          onClick={() => setIsCreateOpen(true)}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Create New Group</span>
        </button>
      </div>

      {/* Category Segmented Filter */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 border-b border-slate-100 text-xs">
        {[
          { id: 'all', label: 'All Groups' },
          { id: 'Life Group', label: 'Life Groups' },
          { id: 'Bible Study', label: 'Bible Studies' },
          { id: 'Ministry Team', label: 'Ministry Teams' },
          { id: 'Youth', label: 'Youth' },
          { id: 'Men', label: 'Men\'s' },
          { id: 'Women', label: 'Women\'s' },
        ].map(cat => (
          <button
            key={cat.id}
            onClick={() => setCategoryFilter(cat.id)}
            className={`px-3 py-1.5 font-medium rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
              categoryFilter === cat.id
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Groups Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredGroups.map(g => {
          const enrolledCount = g.memberIds.length;
          const capacityPct = Math.min(100, Math.round((enrolledCount / g.capacity) * 100));

          return (
            <div
              key={g.id}
              onClick={() => setSelectedGroup(g)}
              className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs hover:border-amber-300 transition-all cursor-pointer flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-semibold text-amber-800 bg-amber-50 px-2 py-0.5 rounded">
                    {g.category}
                  </span>
                  <span className="text-[11px] text-slate-500 tabular-nums">
                    {enrolledCount} / {g.capacity} members
                  </span>
                </div>

                <h3 className="font-display text-lg font-bold text-slate-900 group-hover:text-amber-900 transition-colors">
                  {g.name}
                </h3>

                <p className="text-xs text-slate-600 line-clamp-2 mt-1 mb-4 leading-relaxed">
                  {g.description}
                </p>

                <div className="space-y-1.5 text-xs text-slate-500 mb-4 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{g.meetingSchedule}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{g.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>Leader: <strong className="text-slate-800">{g.leaderName}</strong></span>
                  </div>
                </div>
              </div>

              <div>
                {/* Capacity Progress Bar */}
                <div className="space-y-1 mb-3">
                  <div className="flex justify-between text-[11px] text-slate-500">
                    <span>Capacity Fill</span>
                    <span className="font-semibold text-slate-700">{capacityPct}%</span>
                  </div>
                  <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all ${
                        capacityPct >= 90 ? 'bg-amber-600' : 'bg-slate-800'
                      }`} 
                      style={{ width: `${capacityPct}%` }} 
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs pt-1 text-slate-500">
                  <span className="flex items-center gap-1">
                    <Heart className="w-3 h-3 text-rose-500" />
                    <span>{g.prayerRequests.length} prayers</span>
                  </span>
                  <span className="text-amber-800 font-semibold group-hover:translate-x-0.5 transition-transform inline-flex items-center">
                    Open Workspace <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Group Detail Workspace Drawer */}
      {selectedGroup && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex justify-end">
          <div className="w-full max-w-2xl bg-white h-full shadow-2xl overflow-y-auto flex flex-col">
            
            {/* Drawer Header */}
            <div className="p-6 bg-slate-900 text-white relative">
              <button
                onClick={() => setSelectedGroup(null)}
                className="absolute top-5 right-5 p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2 text-xs text-amber-400 font-semibold uppercase tracking-wider mb-1">
                <span>{selectedGroup.category}</span>
                <span>·</span>
                <span>Leader: {selectedGroup.leaderName}</span>
              </div>
              <h3 className="font-display text-2xl font-bold">{selectedGroup.name}</h3>
              <div className="flex flex-wrap gap-4 text-xs text-slate-300 mt-2">
                <span className="flex items-center gap-1.5"><Clock className="w-3.5 h-3.5 text-amber-400" /> {selectedGroup.meetingSchedule}</span>
                <span className="flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5 text-amber-400" /> {selectedGroup.location}</span>
              </div>
            </div>

            {/* Drawer Body */}
            <div className="p-6 space-y-6 flex-1 text-xs">
              
              {/* Description */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/80">
                <h4 className="font-semibold text-slate-900 mb-1">About This Group</h4>
                <p className="text-slate-600 leading-relaxed">{selectedGroup.description}</p>
              </div>

              {/* Group Roster Management */}
              <div className="border border-slate-200 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="font-bold text-slate-900">Enrolled Roster ({selectedGroup.memberIds.length} / {selectedGroup.capacity})</h4>
                    <span className="text-[11px] text-slate-500">Manage church members connected to this fellowship</span>
                  </div>
                </div>

                {/* Add member to group select */}
                <div className="flex gap-2 mb-4">
                  <select
                    value={memberToAddId}
                    onChange={(e) => setMemberToAddId(e.target.value)}
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs"
                  >
                    <option value="">Select church member to enroll...</option>
                    {members
                      .filter(m => !selectedGroup.memberIds.includes(m.id))
                      .map(m => (
                        <option key={m.id} value={m.id}>
                          {m.firstName} {m.lastName} ({m.membershipStatus} - {m.householdRole})
                        </option>
                      ))}
                  </select>
                  <button
                    type="button"
                    onClick={handleAddMemberToGroup}
                    disabled={!memberToAddId}
                    className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                  >
                    + Enroll Member
                  </button>
                </div>

                {/* Member Roster List */}
                <div className="space-y-1.5">
                  {selectedGroup.memberIds.map(memId => {
                    const m = members.find(mem => mem.id === memId);
                    if (!m) return null;
                    const isLeader = m.id === selectedGroup.leaderId;
                    return (
                      <div key={m.id} className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <div className="w-7 h-7 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold text-xs">
                            {m.firstName[0]}
                          </div>
                          <div>
                            <span className="font-semibold text-slate-900">{m.firstName} {m.lastName}</span>
                            <div className="text-[10px] text-slate-400">
                              {isLeader ? 'Group Leader' : m.householdRole} · {m.campus}
                            </div>
                          </div>
                        </div>

                        {!isLeader && (
                          <button
                            onClick={() => handleRemoveMember(m.id)}
                            className="text-[11px] text-slate-400 hover:text-rose-700 cursor-pointer"
                          >
                            Remove
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Group Prayer Requests */}
              <div className="border border-slate-200 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="font-bold text-slate-900">Group Prayer Requests & Praise</h4>
                    <span className="text-[11px] text-slate-500">Shared intercession within this small group</span>
                  </div>
                </div>

                {/* Add prayer request form */}
                <form onSubmit={handleAddPrayer} className="mb-4 bg-amber-50/50 p-3 rounded-lg border border-amber-100 space-y-2">
                  <div className="grid grid-cols-3 gap-2">
                    <input
                      type="text"
                      placeholder="Requester Name"
                      value={newPrayerAuthor}
                      onChange={(e) => setNewPrayerAuthor(e.target.value)}
                      className="bg-white border border-slate-200 rounded p-1.5 text-xs col-span-1"
                    />
                    <input
                      type="text"
                      required
                      placeholder="Prayer need or celebration..."
                      value={newPrayerText}
                      onChange={(e) => setNewPrayerText(e.target.value)}
                      className="bg-white border border-slate-200 rounded p-1.5 text-xs col-span-2"
                    />
                  </div>
                  <div className="text-right">
                    <button
                      type="submit"
                      className="px-3 py-1 bg-amber-800 hover:bg-amber-900 text-white font-semibold text-xs rounded transition-colors"
                    >
                      Post Prayer Need
                    </button>
                  </div>
                </form>

                <div className="space-y-2">
                  {selectedGroup.prayerRequests.length === 0 ? (
                    <p className="text-slate-400 italic">No prayer requests recorded yet for this group.</p>
                  ) : (
                    selectedGroup.prayerRequests.map(pr => (
                      <div key={pr.id} className="p-3 bg-slate-50 rounded-lg border border-slate-100 flex items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-semibold text-slate-900">{pr.author}</span>
                            <span className="text-[10px] text-slate-400">{pr.date}</span>
                          </div>
                          <p className={`text-slate-700 leading-relaxed ${pr.isAnswered ? 'line-through text-slate-400' : ''}`}>
                            {pr.request}
                          </p>
                        </div>
                        <button
                          onClick={() => {
                            toggleGroupPrayerAnswered(selectedGroup.id, pr.id);
                            setSelectedGroup({
                              ...selectedGroup,
                              prayerRequests: selectedGroup.prayerRequests.map(p =>
                                p.id === pr.id ? { ...p, isAnswered: !p.isAnswered } : p
                              )
                            });
                          }}
                          className={`shrink-0 px-2 py-1 rounded text-[10px] font-semibold cursor-pointer transition-colors ${
                            pr.isAnswered 
                              ? 'bg-emerald-100 text-emerald-800' 
                              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          {pr.isAnswered ? 'Answered Praise!' : 'Mark Answered'}
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Discussions & Announcements */}
              <div className="border border-slate-200 rounded-xl p-4">
                <h4 className="font-bold text-slate-900 mb-3">Study Announcements & Fellowship Chat</h4>
                
                <form onSubmit={handlePostDiscussion} className="mb-4 space-y-2">
                  <textarea
                    rows={2}
                    required
                    placeholder="Post a message or Bible reading assignment for group members..."
                    value={newDiscussionContent}
                    onChange={(e) => setNewDiscussionContent(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs focus:ring-1 focus:ring-amber-500"
                  />
                  <div className="flex justify-between items-center">
                    <input
                      type="text"
                      value={newDiscussionAuthor}
                      onChange={(e) => setNewDiscussionAuthor(e.target.value)}
                      placeholder="Your name"
                      className="bg-slate-50 border border-slate-200 rounded p-1 text-xs w-48"
                    />
                    <button
                      type="submit"
                      className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-lg transition-colors cursor-pointer"
                    >
                      Post Message
                    </button>
                  </div>
                </form>

                <div className="space-y-3">
                  {selectedGroup.discussions.length === 0 ? (
                    <p className="text-slate-400 italic">No discussion notes posted yet.</p>
                  ) : (
                    selectedGroup.discussions.map(disc => (
                      <div key={disc.id} className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-semibold text-slate-900">{disc.author}</span>
                          <span className="text-[10px] text-slate-400">{disc.date}</span>
                        </div>
                        <p className="text-slate-700 leading-relaxed">{disc.content}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>

            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end">
              <button
                onClick={() => setSelectedGroup(null)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg cursor-pointer"
              >
                Close Workspace
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Create Group Modal */}
      <CreateGroupModal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
      />

    </div>
  );
};
