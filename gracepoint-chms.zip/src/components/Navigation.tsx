import React from 'react';
import { useChurch } from '../context/ChurchContext';
import { 
  Users, 
  HeartHandshake, 
  Calendar, 
  QrCode, 
  LayoutDashboard, 
  FolderHeart,
  Plus,
  RefreshCw,
  Church
} from 'lucide-react';
import { Campus } from '../types';

export type ActiveTab = 'overview' | 'members' | 'giving' | 'groups' | 'events' | 'checkin' | 'care';

interface NavigationProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenQuickAdd: () => void;
  onLaunchKiosk: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  setActiveTab,
  onOpenQuickAdd,
  onLaunchKiosk,
}) => {
  const { activeCampus, setActiveCampus, resetToDemoData } = useChurch();

  const navItems: { id: ActiveTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'members', label: 'Members', icon: Users },
    { id: 'giving', label: 'Giving', icon: HeartHandshake },
    { id: 'groups', label: 'Groups', icon: FolderHeart },
    { id: 'events', label: 'Events', icon: Calendar },
    { id: 'checkin', label: 'Check-in', icon: QrCode },
    { id: 'care', label: 'Care', icon: Church },
  ];

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 rounded-lg bg-amber-700 text-white flex items-center justify-center font-display text-lg font-bold shadow-xs">
              GP
            </div>
            <button 
              onClick={() => setActiveTab('overview')}
              className="text-left group cursor-pointer"
            >
              <span className="font-display text-xl font-bold tracking-tight text-slate-900 group-hover:text-amber-800 transition-colors">
                GracePoint
              </span>
            </button>
          </div>

          {/* Zone 2: Clean text navigation links, single-line, 1-2 words */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-md whitespace-nowrap transition-colors cursor-pointer ${
                    isActive 
                      ? 'bg-amber-50 text-amber-900 border border-amber-200/60 font-semibold' 
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-amber-700' : 'text-slate-500'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1-2 primary actions */}
          <div className="flex items-center gap-2.5 shrink-0">
            {/* Campus Switcher */}
            <select
              value={activeCampus}
              onChange={(e) => setActiveCampus(e.target.value as Campus | 'All Campuses')}
              aria-label="Select Campus"
              className="hidden lg:block text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-amber-500 cursor-pointer"
            >
              <option value="All Campuses">All Campuses</option>
              <option value="Main Sanctuary">Main Sanctuary</option>
              <option value="North Campus">North Campus</option>
              <option value="Online Campus">Online Campus</option>
            </select>

            <button
              onClick={onLaunchKiosk}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-950 bg-amber-100 hover:bg-amber-200 border border-amber-300/80 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
              title="Launch Sunday Check-In Kiosk Screen"
            >
              <QrCode className="w-3.5 h-3.5 text-amber-800" />
              <span>Kiosk Mode</span>
            </button>

            <button
              onClick={onOpenQuickAdd}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer whitespace-nowrap shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Record / Add</span>
            </button>

            <button
              onClick={() => {
                if (window.confirm('Reset all demo data back to default initial state?')) {
                  resetToDemoData();
                }
              }}
              className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              title="Reset Demo Records"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>

        {/* Mobile secondary tab bar */}
        <div className="flex md:hidden items-center justify-between border-t border-slate-100 py-2 overflow-x-auto gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center justify-center py-1 px-2 text-xs rounded-md whitespace-nowrap ${
                  isActive ? 'text-amber-800 font-semibold bg-amber-50' : 'text-slate-600'
                }`}
              >
                <Icon className="w-4 h-4 mb-0.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

      </div>
    </header>
  );
};
