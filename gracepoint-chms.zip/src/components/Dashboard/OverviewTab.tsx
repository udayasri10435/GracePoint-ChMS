import React from 'react';
import { useChurch } from '../../context/ChurchContext';
import { 
  Users, 
  HeartHandshake, 
  Calendar, 
  QrCode, 
  TrendingUp, 
  ArrowUpRight,
  ShieldCheck,
  Sparkles,
  Clock,
  MapPin,
  ChevronRight
} from 'lucide-react';
import { ActiveTab } from '../Navigation';

interface OverviewTabProps {
  onNavigateTab: (tab: ActiveTab) => void;
  onRecordDonation: () => void;
  onAddMember: () => void;
  onLaunchKiosk: () => void;
}

export const OverviewTab: React.FC<OverviewTabProps> = ({
  onNavigateTab,
  onRecordDonation,
  onAddMember,
  onLaunchKiosk,
}) => {
  const { 
    members, 
    donations, 
    groups, 
    events, 
    checkIns, 
    prayerRequests, 
    guestFollowUps,
    activeCampus 
  } = useChurch();

  // Filter based on activeCampus if not All
  const filteredMembers = activeCampus === 'All Campuses' 
    ? members 
    : members.filter(m => m.campus === activeCampus);

  const filteredEvents = activeCampus === 'All Campuses'
    ? events
    : events.filter(e => e.campus === activeCampus);

  // Financial stats
  const totalDonations = donations.reduce((sum, d) => sum + d.amount, 0);
  const thisMonthDonations = donations
    .filter(d => d.date.startsWith('2026-09'))
    .reduce((sum, d) => sum + d.amount, 0);
  
  const monthlyGoal = 6500;
  const goalProgress = Math.min(100, Math.round((thisMonthDonations / monthlyGoal) * 100));

  // Active checked in children
  const activeCheckIns = checkIns.filter(c => c.status === 'Checked In');

  // Next upcoming service/event
  const upcomingEvent = filteredEvents[0];

  return (
    <div className="space-y-6">
      
      {/* Welcome Banner / Church Header */}
      <div className="bg-slate-900 text-white rounded-xl p-6 sm:p-8 relative overflow-hidden shadow-sm">
        <div className="relative z-10 max-w-3xl">
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 tracking-wider uppercase mb-2">
            <span>GracePoint Community Church</span>
            <span aria-hidden="true">·</span>
            <span>{activeCampus}</span>
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white mb-3">
            Sunday Ministry & Congregation Operations
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6 max-w-2xl">
            Managing church members, tithe records, small groups discipleship, volunteer schedules, and children’s secure Sunday check-in.
          </p>

          <div className="flex flex-wrap gap-2.5">
            <button
              onClick={onLaunchKiosk}
              className="inline-flex items-center gap-2 px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer shadow-xs"
            >
              <QrCode className="w-4 h-4" />
              <span>Open Check-in Kiosk</span>
            </button>
            <button
              onClick={onRecordDonation}
              className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold rounded-lg border border-white/20 transition-colors cursor-pointer"
            >
              <HeartHandshake className="w-4 h-4" />
              <span>Record Contribution</span>
            </button>
            <button
              onClick={onAddMember}
              className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold rounded-lg border border-white/20 transition-colors cursor-pointer"
            >
              <Users className="w-4 h-4" />
              <span>New Member Form</span>
            </button>
          </div>
        </div>

        {/* Decorative subtle ecclesiastical pattern */}
        <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-10 pointer-events-none flex items-center justify-center">
          <svg className="w-96 h-96 text-white" viewBox="0 0 200 200" fill="currentColor">
            <circle cx="100" cy="100" r="90" fill="none" stroke="currentColor" strokeWidth="2" />
            <circle cx="100" cy="100" r="60" fill="none" stroke="currentColor" strokeWidth="1" />
            <path d="M100 20 V180 M20 100 H180" stroke="currentColor" strokeWidth="2" />
          </svg>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Members KPI */}
        <div 
          onClick={() => onNavigateTab('members')}
          className="bg-white border border-slate-200 rounded-xl p-5 hover:border-amber-300 transition-colors cursor-pointer shadow-xs group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500">Active Congregation</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-800 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <span className="font-display text-2xl font-bold text-slate-900 tabular-nums">
              {filteredMembers.length}
            </span>
            <span className="text-xs text-emerald-700 font-medium flex items-center">
              <TrendingUp className="w-3 h-3 mr-0.5" /> +2 this month
            </span>
          </div>
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>{members.filter(m => m.membershipStatus === 'Member').length} Voting Members</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-700 group-hover:translate-x-0.5 transition-all" />
          </div>
        </div>

        {/* Giving KPI */}
        <div 
          onClick={() => onNavigateTab('giving')}
          className="bg-white border border-slate-200 rounded-xl p-5 hover:border-amber-300 transition-colors cursor-pointer shadow-xs group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500">September Giving</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-800 flex items-center justify-center">
              <HeartHandshake className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <span className="font-display text-2xl font-bold text-slate-900 tabular-nums">
              ${thisMonthDonations.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </span>
          </div>
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>{goalProgress}% of ${monthlyGoal.toLocaleString()} monthly goal</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-700 group-hover:translate-x-0.5 transition-all" />
          </div>
        </div>

        {/* Groups KPI */}
        <div 
          onClick={() => onNavigateTab('groups')}
          className="bg-white border border-slate-200 rounded-xl p-5 hover:border-amber-300 transition-colors cursor-pointer shadow-xs group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500">Life Groups & Teams</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-800 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <span className="font-display text-2xl font-bold text-slate-900 tabular-nums">
              {groups.length}
            </span>
            <span className="text-xs text-slate-500 font-medium">Active fellowships</span>
          </div>
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>82% roster engagement</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-700 group-hover:translate-x-0.5 transition-all" />
          </div>
        </div>

        {/* Check-in KPI */}
        <div 
          onClick={() => onNavigateTab('checkin')}
          className="bg-white border border-slate-200 rounded-xl p-5 hover:border-amber-300 transition-colors cursor-pointer shadow-xs group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500">Sunday Child Check-in</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-800 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <span className="font-display text-2xl font-bold text-slate-900 tabular-nums">
              {activeCheckIns.length}
            </span>
            <span className="text-xs text-amber-700 font-medium">currently in rooms</span>
          </div>
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>{checkIns.length} total logged today</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-700 group-hover:translate-x-0.5 transition-all" />
          </div>
        </div>

      </div>

      {/* Two Column Layout: Attendance & Giving vs Upcoming Services & Pastoral Care */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column (2 spans): Weekly Attendance Trend & Fund Distribution */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Sunday Attendance Trends Chart */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Sunday Service Attendance Trend</h3>
                <p className="text-xs text-slate-500">Weekly count across Sanctuary, GraceKids, and North Campus</p>
              </div>
              <div className="flex items-center gap-3 text-xs text-slate-600">
                <span className="inline-flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-900"></span> Main Sanctuary
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-600"></span> GraceKids
                </span>
              </div>
            </div>

            {/* SVG Visual Attendance Chart */}
            <div className="h-48 w-full pt-4">
              <div className="relative h-full flex items-end justify-between gap-3 px-2">
                {[
                  { week: 'Aug 30', main: 215, kids: 48 },
                  { week: 'Sep 06', main: 230, kids: 52 },
                  { week: 'Sep 13', main: 242, kids: 56 },
                  { week: 'Sep 20', main: 228, kids: 50 },
                  { week: 'Sep 27', main: 254, kids: 62 },
                ].map((col, idx) => {
                  const mainHeight = (col.main / 300) * 100;
                  const kidsHeight = (col.kids / 100) * 100;
                  return (
                    <div key={idx} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                      <div className="w-full max-w-[48px] flex items-end justify-center gap-1.5 h-full">
                        {/* Main Sanctuary Bar */}
                        <div 
                          style={{ height: `${mainHeight}%` }} 
                          className="w-1/2 bg-slate-800 rounded-t-sm transition-all group-hover:bg-slate-700 relative"
                        >
                          <div className="opacity-0 group-hover:opacity-100 absolute -top-7 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] py-0.5 px-1.5 rounded pointer-events-none whitespace-nowrap z-10 tabular-nums">
                            {col.main} adults
                          </div>
                        </div>
                        {/* Kids Bar */}
                        <div 
                          style={{ height: `${kidsHeight * 0.5}%` }} 
                          className="w-1/2 bg-amber-600 rounded-t-sm transition-all group-hover:bg-amber-500 relative"
                        >
                          <div className="opacity-0 group-hover:opacity-100 absolute -top-7 left-1/2 -translate-x-1/2 bg-amber-900 text-white text-[10px] py-0.5 px-1.5 rounded pointer-events-none whitespace-nowrap z-10 tabular-nums">
                            {col.kids} kids
                          </div>
                        </div>
                      </div>
                      <span className="text-[11px] font-medium text-slate-500 whitespace-nowrap">{col.week}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span>Average Sunday Attendance: <strong className="text-slate-800 font-semibold tabular-nums">288 total</strong></span>
              <button 
                onClick={() => onNavigateTab('events')} 
                className="text-amber-800 hover:text-amber-900 font-medium inline-flex items-center gap-1 cursor-pointer"
              >
                View Services Calendar <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Fund Breakdown & Recent Contributions */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Giving by Designated Fund</h3>
                <p className="text-xs text-slate-500">YTD allocation across church ministries</p>
              </div>
              <button
                onClick={() => onNavigateTab('giving')}
                className="text-xs font-semibold text-amber-800 hover:text-amber-900 cursor-pointer"
              >
                View Ledger
              </button>
            </div>

            {/* Fund Breakdown Bars */}
            <div className="space-y-3 mb-6">
              {[
                { name: 'Tithe & General', amount: 1900, total: totalDonations, color: 'bg-slate-900' },
                { name: 'Building Campaign', amount: 1200, total: totalDonations, color: 'bg-amber-600' },
                { name: 'Benevolence Fund', amount: 300, total: totalDonations, color: 'bg-emerald-600' },
                { name: 'Missions & Outreach', amount: 150, total: totalDonations, color: 'bg-indigo-600' },
                { name: 'Youth & Camp', amount: 100, total: totalDonations, color: 'bg-rose-600' },
              ].map((fund, i) => {
                const pct = Math.round((fund.amount / totalDonations) * 100) || 0;
                return (
                  <div key={i} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-medium text-slate-700">{fund.name}</span>
                      <span className="text-slate-500 tabular-nums">
                        ${fund.amount.toLocaleString()} <span className="text-slate-400">({pct}%)</span>
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${fund.color} rounded-full transition-all`} 
                        style={{ width: `${pct}%` }} 
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Recent Giving Transactions */}
            <div>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-2">
                Recent Tithes & Contributions
              </span>
              <div className="divide-y divide-slate-100 border border-slate-100 rounded-lg overflow-hidden">
                {donations.slice(0, 4).map((d) => (
                  <div key={d.id} className="p-3 flex items-center justify-between hover:bg-slate-50 transition-colors">
                    <div>
                      <div className="text-xs font-semibold text-slate-900">{d.memberName}</div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                        <span>{d.fund}</span>
                        <span>·</span>
                        <span>{d.method}</span>
                        {d.recurring && <span>· Monthly</span>}
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-bold text-slate-900 tabular-nums">
                        +${d.amount.toFixed(2)}
                      </span>
                      <div className="text-[10px] text-slate-400">{d.date}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>

        {/* Right Column: Upcoming Worship Services & Volunteer Coverage */}
        <div className="space-y-6">
          
          {/* Next Worship Service Roster */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-900">Upcoming Service</h3>
              <span className="text-xs font-medium text-amber-800 bg-amber-50 px-2 py-0.5 rounded">
                This Sunday
              </span>
            </div>

            {upcomingEvent && (
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-slate-900 text-sm">{upcomingEvent.title}</h4>
                  <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>{upcomingEvent.date} · {upcomingEvent.startTime}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    <span>{upcomingEvent.locationRoom} ({upcomingEvent.campus})</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100">
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="font-medium text-slate-700">Volunteer Coverage</span>
                    <span className="text-amber-800 font-semibold">
                      {upcomingEvent.volunteerSlots.reduce((acc, s) => acc + s.assignedMemberIds.length, 0)} of{' '}
                      {upcomingEvent.volunteerSlots.reduce((acc, s) => acc + s.countRequired, 0)} confirmed
                    </span>
                  </div>

                  <div className="space-y-2">
                    {upcomingEvent.volunteerSlots.map((slot) => {
                      const isFilled = slot.assignedMemberIds.length >= slot.countRequired;
                      return (
                        <div key={slot.id} className="text-xs p-2 rounded bg-slate-50 border border-slate-100 flex items-center justify-between">
                          <div>
                            <span className="font-medium text-slate-800">{slot.roleTitle}</span>
                            <div className="text-[11px] text-slate-500">{slot.team}</div>
                          </div>
                          <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                            isFilled ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-900'
                          }`}>
                            {slot.assignedMemberIds.length}/{slot.countRequired}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <button
                  onClick={() => onNavigateTab('events')}
                  className="w-full text-center py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors cursor-pointer"
                >
                  Manage Service Rosters
                </button>
              </div>
            )}
          </div>

          {/* First-Time Guest Follow-ups */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-900">First-Time Visitors</h3>
              <button 
                onClick={() => onNavigateTab('care')}
                className="text-xs text-amber-800 hover:text-amber-900 font-medium cursor-pointer"
              >
                Care Pipeline
              </button>
            </div>

            <div className="space-y-3">
              {guestFollowUps.slice(0, 3).map((g) => (
                <div key={g.id} className="p-2.5 rounded-lg border border-slate-100 hover:border-slate-200 transition-colors">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-semibold text-slate-900">{g.guestName}</span>
                    <span className="text-[10px] font-medium text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                      {g.stage}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 line-clamp-1">{g.notes}</p>
                  <div className="text-[10px] text-slate-400 mt-1">Assigned: {g.assignedLeader}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Prayer Needs & Praise Board */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-900">Pastoral Prayer Requests</h3>
              <span className="text-xs text-slate-500">{prayerRequests.length} Active</span>
            </div>

            <div className="space-y-2.5">
              {prayerRequests.slice(0, 3).map((pr) => (
                <div key={pr.id} className="text-xs p-2.5 rounded-lg bg-amber-50/50 border border-amber-100">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-slate-900">{pr.requesterName}</span>
                    <span className={`text-[10px] font-medium px-1.5 py-0.2 rounded ${
                      pr.status === 'Answered' ? 'bg-emerald-100 text-emerald-800' : 'text-amber-800'
                    }`}>
                      {pr.status === 'Answered' ? 'Answered Praise' : 'In Prayer'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 line-clamp-2">{pr.requestText}</p>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
