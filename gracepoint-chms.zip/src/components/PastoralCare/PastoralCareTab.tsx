import React, { useState } from 'react';
import { useChurch } from '../../context/ChurchContext';
import { GuestFollowUp, GeneralPrayerRequest } from '../../types';
import { 
  Heart, 
  Plus, 
  Phone, 
  Mail, 
  Calendar, 
  Sparkles, 
  CheckCircle, 
  ChevronRight, 
  UserCheck, 
  MessageSquare,
  X,
  Church
} from 'lucide-react';

export const PastoralCareTab: React.FC = () => {
  const { 
    guestFollowUps, 
    updateGuestStage, 
    addGuestFollowUp, 
    prayerRequests, 
    togglePrayerStatus, 
    addPrayerRequest 
  } = useChurch();

  const [activeSubTab, setActiveSubTab] = useState<'pipeline' | 'prayers'>('pipeline');
  
  // New Guest modal state
  const [isAddGuestOpen, setIsAddGuestOpen] = useState(false);
  const [newGuestName, setNewGuestName] = useState('');
  const [newGuestPhone, setNewGuestPhone] = useState('');
  const [newGuestEmail, setNewGuestEmail] = useState('');
  const [newGuestNotes, setNewGuestNotes] = useState('');
  const [newGuestLeader, setNewGuestLeader] = useState('Pastor David Sterling');

  // New Prayer form state
  const [isAddPrayerOpen, setIsAddPrayerOpen] = useState(false);
  const [prayerRequester, setPrayerRequester] = useState('');
  const [prayerContent, setPrayerContent] = useState('');
  const [prayerIsPublic, setPrayerIsPublic] = useState(true);

  // Pipeline stages
  const stages: GuestFollowUp['stage'][] = [
    'New Visitor',
    'Welcome Contact',
    'Pastoral Connect',
    'Invited to Group',
    'Integrated Member',
  ];

  const handleCreateGuest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGuestName.trim()) return;

    addGuestFollowUp({
      guestName: newGuestName.trim(),
      phone: newGuestPhone.trim(),
      email: newGuestEmail.trim(),
      firstVisitDate: new Date().toISOString().split('T')[0],
      assignedLeader: newGuestLeader,
      stage: 'New Visitor',
      notes: newGuestNotes.trim() || 'First-time Sunday visitor, requested follow-up.',
    });

    setNewGuestName('');
    setNewGuestPhone('');
    setNewGuestEmail('');
    setNewGuestNotes('');
    setIsAddGuestOpen(false);
  };

  const handleCreatePrayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prayerContent.trim()) return;

    addPrayerRequest({
      requesterName: prayerRequester.trim() || 'Anonymous Member',
      requestText: prayerContent.trim(),
      isPublic: prayerIsPublic,
    });

    setPrayerRequester('');
    setPrayerContent('');
    setIsAddPrayerOpen(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h2 className="font-display text-2xl font-bold text-slate-900">Pastoral Care & Discipleship</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Guest integration pipeline, shepherd visitation notes, and prayer ministry intercession
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Sub-tab switcher */}
          <div className="flex items-center p-1 bg-slate-100 rounded-lg text-xs font-medium">
            <button
              onClick={() => setActiveSubTab('pipeline')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                activeSubTab === 'pipeline' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Visitor Pipeline
            </button>
            <button
              onClick={() => setActiveSubTab('prayers')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                activeSubTab === 'prayers' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Prayer Ministry
            </button>
          </div>

          {activeSubTab === 'pipeline' ? (
            <button
              onClick={() => setIsAddGuestOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Guest Lead</span>
            </button>
          ) : (
            <button
              onClick={() => setIsAddPrayerOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Prayer Request</span>
            </button>
          )}
        </div>
      </div>

      {activeSubTab === 'pipeline' ? (
        /* Visitor Follow-Up Kanban Pipeline */
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            {stages.map((stage, stageIdx) => {
              const guestsInStage = guestFollowUps.filter(g => g.stage === stage);

              return (
                <div key={stage} className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-col justify-between min-h-[460px]">
                  <div>
                    <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-200">
                      <span className="font-semibold text-slate-800 text-xs">{stage}</span>
                      <span className="text-[10px] font-bold bg-white text-slate-700 px-2 py-0.5 rounded-full border border-slate-200">
                        {guestsInStage.length}
                      </span>
                    </div>

                    <div className="space-y-2.5">
                      {guestsInStage.length === 0 ? (
                        <div className="py-8 text-center text-slate-400 text-[11px] italic">
                          No guests in this stage
                        </div>
                      ) : (
                        guestsInStage.map(guest => (
                          <div
                            key={guest.id}
                            className="bg-white border border-slate-200 rounded-xl p-3 shadow-xs hover:border-amber-400 transition-colors space-y-2 text-xs"
                          >
                            <div className="font-bold text-slate-900">{guest.guestName}</div>
                            
                            <p className="text-[11px] text-slate-600 leading-relaxed line-clamp-3">
                              {guest.notes}
                            </p>

                            <div className="space-y-1 text-[10px] text-slate-500 pt-1 border-t border-slate-100">
                              {guest.phone && (
                                <div className="flex items-center gap-1">
                                  <Phone className="w-3 h-3 text-slate-400" />
                                  <span>{guest.phone}</span>
                                </div>
                              )}
                              {guest.email && (
                                <div className="flex items-center gap-1 truncate">
                                  <Mail className="w-3 h-3 text-slate-400" />
                                  <span className="truncate">{guest.email}</span>
                                </div>
                              )}
                              <div className="text-slate-400 mt-0.5">
                                Assigned: <strong className="text-slate-700">{guest.assignedLeader}</strong>
                              </div>
                            </div>

                            {/* Stage progression controls */}
                            <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                              {stageIdx > 0 && (
                                <button
                                  onClick={() => updateGuestStage(guest.id, stages[stageIdx - 1])}
                                  className="text-[10px] text-slate-500 hover:text-slate-800 cursor-pointer"
                                >
                                  ← Back
                                </button>
                              )}
                              {stageIdx < stages.length - 1 && (
                                <button
                                  onClick={() => updateGuestStage(guest.id, stages[stageIdx + 1])}
                                  className="text-[10px] text-amber-800 hover:text-amber-900 font-semibold inline-flex items-center ml-auto cursor-pointer"
                                >
                                  Advance →
                                </button>
                              )}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-200/80 text-[10px] text-slate-400 text-center">
                    Step {stageIdx + 1} of 5
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* Prayer Requests & Praises Board */
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {prayerRequests.map(pr => {
              const isAnswered = pr.status === 'Answered';
              return (
                <div
                  key={pr.id}
                  className={`bg-white border rounded-xl p-5 shadow-xs transition-colors flex flex-col justify-between ${
                    isAnswered ? 'border-emerald-200 bg-emerald-50/20' : 'border-slate-200'
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-sm">{pr.requesterName}</span>
                        {!pr.isPublic && (
                          <span className="text-[10px] font-semibold text-purple-900 bg-purple-50 border border-purple-200 px-1.5 py-0.2 rounded">
                            Confidential / Pastoral
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400 tabular-nums">{pr.dateSubmitted}</span>
                    </div>

                    <p className="text-xs text-slate-700 leading-relaxed">
                      {pr.requestText}
                    </p>

                    {pr.answeredNote && (
                      <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200 text-xs text-emerald-900 mt-2">
                        <strong className="block mb-0.5 text-emerald-950 font-semibold">Answered Praise Report:</strong>
                        {pr.answeredNote}
                      </div>
                    )}
                  </div>

                  <div className="pt-4 mt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className={`text-[11px] font-semibold flex items-center gap-1 ${
                      isAnswered ? 'text-emerald-700' : 'text-amber-800'
                    }`}>
                      {isAnswered ? <CheckCircle className="w-3.5 h-3.5" /> : <Heart className="w-3.5 h-3.5" />}
                      <span>{isAnswered ? 'Answered Testimony' : 'Active Intercession'}</span>
                    </span>

                    <button
                      onClick={() => togglePrayerStatus(pr.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                        isAnswered 
                          ? 'bg-slate-100 text-slate-700 hover:bg-slate-200' 
                          : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                      }`}
                    >
                      {isAnswered ? 'Reopen for Prayer' : 'Mark as Answered!'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Add Guest Modal */}
      {isAddGuestOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden">
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
              <h3 className="font-display text-base font-bold">Log First-Time Church Guest</h3>
              <button onClick={() => setIsAddGuestOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateGuest} className="p-6 space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Guest Full Name *</label>
                <input
                  type="text"
                  required
                  value={newGuestName}
                  onChange={(e) => setNewGuestName(e.target.value)}
                  placeholder="e.g. Jonathan Edwards"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Phone</label>
                  <input
                    type="tel"
                    value={newGuestPhone}
                    onChange={(e) => setNewGuestPhone(e.target.value)}
                    placeholder="(555) 000-0000"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Email</label>
                  <input
                    type="email"
                    value={newGuestEmail}
                    onChange={(e) => setNewGuestEmail(e.target.value)}
                    placeholder="guest@mail.com"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
                  />
                </div>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Assigned Follow-up Minister</label>
                <input
                  type="text"
                  value={newGuestLeader}
                  onChange={(e) => setNewGuestLeader(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">First Visit Impressions & Prayer Needs</label>
                <textarea
                  rows={3}
                  value={newGuestNotes}
                  onChange={(e) => setNewGuestNotes(e.target.value)}
                  placeholder="Attended 11am service, sat in balcony, has 2 kids..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
                />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddGuestOpen(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-lg font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold shadow-xs"
                >
                  Save to Pipeline
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Prayer Modal */}
      {isAddPrayerOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden">
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
              <h3 className="font-display text-base font-bold">Submit Prayer Request</h3>
              <button onClick={() => setIsAddPrayerOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreatePrayer} className="p-6 space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Requester Name</label>
                <input
                  type="text"
                  value={prayerRequester}
                  onChange={(e) => setPrayerRequester(e.target.value)}
                  placeholder="e.g. Mary or Anonymous"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Prayer Need or Praise Request *</label>
                <textarea
                  rows={4}
                  required
                  value={prayerContent}
                  onChange={(e) => setPrayerContent(e.target.value)}
                  placeholder="Detail the health, family, or spiritual prayer need..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
                />
              </div>
              <label className="flex items-center gap-2 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={prayerIsPublic}
                  onChange={(e) => setPrayerIsPublic(e.target.checked)}
                  className="rounded text-amber-600 focus:ring-amber-500"
                />
                <span className="text-slate-600">Share with church congregation prayer chain (uncheck for pastoral staff only)</span>
              </label>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddPrayerOpen(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-lg font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold shadow-xs"
                >
                  Submit Prayer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
