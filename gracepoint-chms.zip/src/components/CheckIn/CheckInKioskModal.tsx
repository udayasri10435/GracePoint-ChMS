import React, { useState } from 'react';
import { useChurch } from '../../context/ChurchContext';
import { Member, CheckInRecord } from '../../types';
import { 
  X, 
  Search, 
  ShieldCheck, 
  Check, 
  Printer, 
  QrCode, 
  UserCheck, 
  Phone, 
  AlertTriangle,
  RotateCcw
} from 'lucide-react';

interface CheckInKioskModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CheckInKioskModal: React.FC<CheckInKioskModalProps> = ({ isOpen, onClose }) => {
  const { members, households, events, checkInChild } = useChurch();

  const [phoneSearch, setPhoneSearch] = useState('');
  const [selectedHouseholdId, setSelectedHouseholdId] = useState<string | null>(null);
  const [selectedChildIds, setSelectedChildIds] = useState<string[]>([]);
  const [selectedServiceId, setSelectedServiceId] = useState(events[0]?.id || 'evt-1');
  const [allergiesNotes, setAllergiesNotes] = useState<{ [childId: string]: string }>({});
  const [printedRecords, setPrintedRecords] = useState<CheckInRecord[] | null>(null);

  if (!isOpen) return null;

  // Search matching households
  const matchingHouseholds = households.filter(hh => {
    if (!phoneSearch.trim()) return false;
    const cleanSearch = phoneSearch.replace(/\D/g, '');
    const cleanEmergencyPhone = hh.emergencyContact.phone.replace(/\D/g, '');
    
    // Check if any member in household matches phone or name
    const familyMembers = members.filter(m => hh.memberIds.includes(m.id));
    const memberMatches = familyMembers.some(m => {
      const cleanMemPhone = m.phone.replace(/\D/g, '');
      const nameMatches = `${m.firstName} ${m.lastName}`.toLowerCase().includes(phoneSearch.toLowerCase());
      const phoneMatches = cleanMemPhone.includes(cleanSearch) && cleanSearch.length >= 3;
      return nameMatches || phoneMatches;
    });

    const hhNameMatches = hh.name.toLowerCase().includes(phoneSearch.toLowerCase());
    const emergencyMatches = cleanEmergencyPhone.includes(cleanSearch) && cleanSearch.length >= 3;

    return memberMatches || hhNameMatches || emergencyMatches;
  });

  const activeHousehold = households.find(h => h.id === selectedHouseholdId);
  const householdChildren = activeHousehold 
    ? members.filter(m => activeHousehold.memberIds.includes(m.id) && (m.householdRole === 'Child' || m.membershipStatus === 'Regular Attender'))
    : [];

  const handleSelectHousehold = (hhId: string) => {
    setSelectedHouseholdId(hhId);
    const hh = households.find(h => h.id === hhId);
    const kids = members.filter(m => hh?.memberIds.includes(m.id) && (m.householdRole === 'Child' || m.membershipStatus === 'Regular Attender'));
    // Select all kids by default
    setSelectedChildIds(kids.map(k => k.id));
  };

  const toggleChildSelection = (childId: string) => {
    setSelectedChildIds(prev => 
      prev.includes(childId) ? prev.filter(id => id !== childId) : [...prev, childId]
    );
  };

  const handleCompleteCheckIn = () => {
    if (!selectedHouseholdId || selectedChildIds.length === 0) return;

    const chosenService = events.find(e => e.id === selectedServiceId);
    const serviceName = chosenService ? chosenService.title : 'Sunday Morning Celebration';

    const newRecords: CheckInRecord[] = [];

    for (const childId of selectedChildIds) {
      const child = members.find(m => m.id === childId);
      let roomName = 'GraceKids Primary Room 204';
      if (child?.gradeOrAge?.toLowerCase().includes('toddler') || child?.gradeOrAge?.toLowerCase().includes('nursery')) {
        roomName = 'Toddler Nursery (Room 101)';
      } else if (child?.gradeOrAge?.toLowerCase().includes('pre-k')) {
        roomName = 'GraceKids Pre-K (Room 102)';
      }

      const record = checkInChild({
        childId,
        serviceId: selectedServiceId,
        serviceName,
        roomName,
        medicalNotes: allergiesNotes[childId] || child?.allergies,
      });

      newRecords.push(record);
    }

    setPrintedRecords(newRecords);
  };

  const handleResetKiosk = () => {
    setPhoneSearch('');
    setSelectedHouseholdId(null);
    setSelectedChildIds([]);
    setAllergiesNotes({});
    setPrintedRecords(null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden my-4 border border-slate-100 flex flex-col max-h-[92vh]">
        
        {/* Kiosk Top Bar */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-600 flex items-center justify-center text-white font-display font-bold text-lg shadow-sm">
              GP
            </div>
            <div>
              <div className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider">
                GraceKids Security Check-in Kiosk
              </div>
              <h2 className="font-display text-lg font-bold">Welcome Church Families</h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleResetKiosk}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Reset Kiosk Screen"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Close Kiosk Mode"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Kiosk Content */}
        <div className="p-6 overflow-y-auto flex-1 text-xs">
          
          {printedRecords ? (
            /* Badge Print Preview State */
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto mb-2 shadow-xs">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <h3 className="font-display text-2xl font-bold text-slate-900">Check-in Complete!</h3>
                <p className="text-slate-500 mt-0.5">Badges generated with matching parent security pick-up code.</p>
              </div>

              {/* Printable Badges Area */}
              <div id="printable-area" className="space-y-4">
                {printedRecords.map((rec) => (
                  <div key={rec.id} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    
                    {/* 1. Child Name Badge */}
                    <div className="bg-white border-2 border-slate-900 rounded-2xl p-4 shadow-sm relative overflow-hidden">
                      <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                        <div className="font-display font-bold text-xs text-amber-900">GraceKids Sunday School</div>
                        <span className="font-mono text-xs font-bold bg-amber-100 text-amber-950 px-2 py-0.5 rounded">
                          {rec.securityCode}
                        </span>
                      </div>

                      <div className="py-3 text-center">
                        <h4 className="font-display text-2xl font-bold text-slate-900">{rec.childName}</h4>
                        <div className="text-xs font-semibold text-slate-700 mt-1">{rec.roomName}</div>
                      </div>

                      {rec.allergies && rec.allergies !== 'None' && rec.allergies !== 'None recorded' && (
                        <div className="bg-rose-50 border border-rose-200 p-2 rounded-lg text-center font-bold text-rose-900 text-[11px] mb-2 flex items-center justify-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                          <span>ALLERGY: {rec.allergies}</span>
                        </div>
                      )}

                      <div className="pt-2 border-t border-slate-100 flex justify-between text-[10px] text-slate-500">
                        <span>Parent: {rec.parentName}</span>
                        <span>{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                    </div>

                    {/* 2. Parent Security Claim Ticket */}
                    <div className="bg-slate-900 text-white rounded-2xl p-4 shadow-sm relative overflow-hidden flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-center pb-2 border-b border-slate-700">
                          <div className="font-semibold text-[11px] text-amber-400">Parent Claim Receipt</div>
                          <span className="text-[10px] text-slate-400">Authorized Pick-up Tag</span>
                        </div>

                        <div className="py-2 text-center">
                          <div className="text-[11px] text-slate-300">Security Code Match:</div>
                          <div className="font-mono font-bold text-3xl tracking-widest text-amber-400 my-1">
                            {rec.securityCode}
                          </div>
                          <div className="text-xs text-slate-300">Child: {rec.childName}</div>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-400 text-center">
                        Present this tag or code at dismissal to room supervisor.
                      </div>
                    </div>

                  </div>
                ))}
              </div>

              {/* Actions */}
              <div className="pt-4 border-t border-slate-200 flex flex-wrap gap-3 justify-center">
                <button
                  onClick={() => window.print()}
                  className="inline-flex items-center gap-2 px-5 py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Physical Badges</span>
                </button>
                <button
                  onClick={handleResetKiosk}
                  className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  Finish & Next Family
                </button>
              </div>

            </div>
          ) : !selectedHouseholdId ? (
            /* Step 1: Search Household / Phone */
            <div className="space-y-6 max-w-md mx-auto py-4">
              
              <div className="text-center">
                <h3 className="font-display text-xl font-bold text-slate-900">Check-In Your Family</h3>
                <p className="text-slate-500 text-xs mt-1">
                  Enter the last 4 digits of phone number or family last name
                </p>
              </div>

              {/* Phone / Name Input */}
              <div className="relative">
                <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  autoFocus
                  value={phoneSearch}
                  onChange={(e) => setPhoneSearch(e.target.value)}
                  placeholder="e.g. 8900, 412, or 'Miller'..."
                  className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border-2 border-slate-200 focus:border-amber-600 rounded-2xl text-base text-slate-900 font-semibold focus:outline-none transition-colors"
                />
              </div>

              {/* Demo Quick Touch Shortcuts */}
              <div>
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-2">
                  Sample Congregation Families (Click to Test)
                </span>
                <div className="space-y-2">
                  {households.map(hh => {
                    const famKids = members.filter(m => hh.memberIds.includes(m.id) && m.householdRole === 'Child');
                    return (
                      <button
                        key={hh.id}
                        type="button"
                        onClick={() => handleSelectHousehold(hh.id)}
                        className="w-full text-left p-3 rounded-xl border border-slate-200 hover:border-amber-400 hover:bg-amber-50/50 transition-all flex items-center justify-between cursor-pointer group"
                      >
                        <div>
                          <div className="font-semibold text-slate-900 text-sm group-hover:text-amber-950">
                            {hh.name}
                          </div>
                          <div className="text-[11px] text-slate-500">
                            Emergency: {hh.emergencyContact.name} · {hh.emergencyContact.phone}
                          </div>
                        </div>
                        <span className="text-[11px] font-medium text-slate-600 bg-slate-100 group-hover:bg-amber-100 group-hover:text-amber-950 px-2.5 py-1 rounded-lg">
                          {famKids.length} children
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

            </div>
          ) : (
            /* Step 2: Select Children & Service */
            <div className="space-y-6 max-w-lg mx-auto py-2">
              
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div>
                  <span className="text-[11px] text-slate-400 uppercase tracking-wider block">Checking In Family</span>
                  <h3 className="font-display text-xl font-bold text-slate-900">{activeHousehold?.name}</h3>
                </div>
                <button
                  onClick={() => setSelectedHouseholdId(null)}
                  className="text-xs text-amber-800 hover:text-amber-900 font-semibold cursor-pointer"
                >
                  Change Family
                </button>
              </div>

              {/* Service Selection */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1.5">Select Service</label>
                <select
                  value={selectedServiceId}
                  onChange={(e) => setSelectedServiceId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-medium"
                >
                  {events
                    .filter(e => e.type === 'Sunday Service' || e.type === 'Midweek Service')
                    .map(e => (
                      <option key={e.id} value={e.id}>
                        {e.title} ({e.date} · {e.startTime})
                      </option>
                    ))}
                </select>
              </div>

              {/* Children Selection */}
              <div className="space-y-3">
                <label className="block font-semibold text-slate-700">Select Children to Check In</label>
                {householdChildren.length === 0 ? (
                  <div className="p-4 bg-slate-50 rounded-xl text-center text-slate-500">
                    No children listed in this household. Would you like to check in an adult attender?
                  </div>
                ) : (
                  householdChildren.map(child => {
                    const isSelected = selectedChildIds.includes(child.id);
                    return (
                      <div
                        key={child.id}
                        className={`p-3.5 rounded-2xl border-2 transition-all ${
                          isSelected 
                            ? 'border-amber-600 bg-amber-50/50' 
                            : 'border-slate-200 bg-white hover:border-slate-300'
                        }`}
                      >
                        <div 
                          onClick={() => toggleChildSelection(child.id)}
                          className="flex items-center justify-between cursor-pointer"
                        >
                          <div className="flex items-center gap-3">
                            <div className={`w-6 h-6 rounded-lg flex items-center justify-center ${
                              isSelected ? 'bg-amber-600 text-white' : 'border border-slate-300 text-transparent'
                            }`}>
                              <Check className="w-4 h-4 stroke-[3]" />
                            </div>
                            <div>
                              <div className="font-bold text-slate-900 text-sm">
                                {child.firstName} {child.lastName}
                              </div>
                              <div className="text-[11px] text-slate-500">
                                {child.gradeOrAge || 'Sunday School'}
                              </div>
                            </div>
                          </div>

                          {child.allergies && (
                            <span className="text-[10px] font-semibold text-rose-800 bg-rose-100 px-2 py-0.5 rounded-md flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3" /> Allergy
                            </span>
                          )}
                        </div>

                        {isSelected && (
                          <div className="mt-3 pt-2.5 border-t border-amber-200/60">
                            <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                              Classroom Notes / Allergy Reminders for Today
                            </label>
                            <input
                              type="text"
                              defaultValue={child.allergies || ''}
                              placeholder="e.g. Grandma picking up, peanut allergy..."
                              onChange={(e) => {
                                setAllergiesNotes(prev => ({
                                  ...prev,
                                  [child.id]: e.target.value
                                }));
                              }}
                              className="w-full bg-white border border-amber-200 rounded-lg p-2 text-xs"
                            />
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>

              {/* Complete Action */}
              <button
                type="button"
                onClick={handleCompleteCheckIn}
                disabled={selectedChildIds.length === 0}
                className="w-full py-3.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold rounded-2xl shadow-sm transition-colors flex items-center justify-center gap-2 cursor-pointer text-sm"
              >
                <Printer className="w-4 h-4" />
                <span>Check In {selectedChildIds.length} {selectedChildIds.length === 1 ? 'Child' : 'Children'} & Print Badges</span>
              </button>

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
