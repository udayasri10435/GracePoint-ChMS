import React, { useState } from 'react';
import { useChurch } from '../../context/ChurchContext';
import { CheckInRecord } from '../../types';
import { 
  ShieldCheck, 
  QrCode, 
  Search, 
  AlertTriangle, 
  Check, 
  Printer, 
  Clock, 
  UserCheck, 
  Phone,
  DoorOpen,
  X,
  KeyRound
} from 'lucide-react';
import { CheckInKioskModal } from './CheckInKioskModal';

export const CheckInTab: React.FC = () => {
  const { checkIns, checkOutChild } = useChurch();

  const [isKioskOpen, setIsKioskOpen] = useState(false);
  const [roomFilter, setRoomFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Security verification checkout modal state
  const [checkoutTarget, setCheckoutTarget] = useState<CheckInRecord | null>(null);
  const [inputSecurityCode, setInputSecurityCode] = useState('');
  const [checkoutFeedback, setCheckoutFeedback] = useState<{ success: boolean; message: string } | null>(null);

  // Badge reprint modal state
  const [badgeToReprint, setBadgeToReprint] = useState<CheckInRecord | null>(null);

  // Stats
  const activeCount = checkIns.filter(c => c.status === 'Checked In').length;
  const pickedUpCount = checkIns.filter(c => c.status === 'Picked Up').length;
  const allergyAlertCount = checkIns.filter(c => c.allergies && c.allergies !== 'None' && c.allergies !== 'None recorded').length;

  const filteredCheckIns = checkIns.filter(c => {
    if (roomFilter !== 'all' && !c.roomName.toLowerCase().includes(roomFilter.toLowerCase())) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchesChild = c.childName.toLowerCase().includes(q);
      const matchesParent = c.parentName.toLowerCase().includes(q);
      const matchesCode = c.securityCode.toLowerCase().includes(q);
      const matchesRoom = c.roomName.toLowerCase().includes(q);
      return matchesChild || matchesParent || matchesCode || matchesRoom;
    }
    return true;
  });

  const handleVerifyCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    if (!checkoutTarget) return;

    const res = checkOutChild(checkoutTarget.id, inputSecurityCode);
    setCheckoutFeedback(res);

    if (res.success) {
      setTimeout(() => {
        setCheckoutTarget(null);
        setInputSecurityCode('');
        setCheckoutFeedback(null);
      }, 1500);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h2 className="font-display text-2xl font-bold text-slate-900">Children & Sunday Check-in Station</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Classroom security rosters, parent claim tags, allergy safety tracking, and child dismissal verification
          </p>
        </div>

        <button
          onClick={() => setIsKioskOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-500 rounded-xl shadow-xs transition-colors cursor-pointer"
        >
          <QrCode className="w-4 h-4" />
          <span>Launch Self-Service Kiosk</span>
        </button>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <span className="text-xs font-medium text-slate-500 block mb-1">Active in Classrooms</span>
          <div className="font-display text-2xl font-bold text-slate-900 tabular-nums">
            {activeCount}
          </div>
          <div className="text-[11px] text-amber-800 font-medium mt-1">
            Supervised by background-checked staff
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <span className="text-xs font-medium text-slate-500 block mb-1">Safely Picked Up</span>
          <div className="font-display text-2xl font-bold text-slate-900 tabular-nums">
            {pickedUpCount}
          </div>
          <div className="text-[11px] text-emerald-700 font-medium mt-1 flex items-center gap-1">
            <Check className="w-3 h-3" /> Security code verified at dismissal
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <span className="text-xs font-medium text-slate-500 block mb-1">Allergy & Medical Alerts</span>
          <div className="font-display text-2xl font-bold text-rose-800 tabular-nums">
            {allergyAlertCount}
          </div>
          <div className="text-[11px] text-rose-700 font-medium mt-1 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" /> High visibility badge flags active
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <span className="text-xs font-medium text-slate-500 block mb-1">Total Attendance Today</span>
          <div className="font-display text-2xl font-bold text-slate-900 tabular-nums">
            {checkIns.length}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Sunday School check-in count
          </div>
        </div>

      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          
          <div className="md:col-span-2 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search child name, parent name, classroom room, or security code..."
              className="w-full pl-9 pr-3 py-2 text-xs text-slate-900 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
          </div>

          <div>
            <select
              value={roomFilter}
              onChange={(e) => setRoomFilter(e.target.value)}
              className="w-full py-2 px-3 text-xs text-slate-700 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none cursor-pointer"
            >
              <option value="all">All Classrooms</option>
              <option value="Toddler">Toddler Nursery (Room 101)</option>
              <option value="Pre-K">GraceKids Pre-K (Room 102)</option>
              <option value="204">GraceKids (Room 204)</option>
            </select>
          </div>

        </div>
      </div>

      {/* Live Check-in Roster Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Child Name & Age</th>
                <th className="py-3 px-4">Classroom Room</th>
                <th className="py-3 px-4">Security Code</th>
                <th className="py-3 px-4">Allergy / Medical Alerts</th>
                <th className="py-3 px-4">Guardian Contact</th>
                <th className="py-3 px-4">Status & Time</th>
                <th className="py-3 px-4 text-right">Dismissal Authorization</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredCheckIns.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500">
                    No children checked into rooms matching current criteria.
                  </td>
                </tr>
              ) : (
                filteredCheckIns.map(chk => {
                  const isCheckedIn = chk.status === 'Checked In';
                  const hasAllergy = chk.allergies && chk.allergies !== 'None' && chk.allergies !== 'None recorded';

                  return (
                    <tr key={chk.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{chk.childName}</div>
                        <div className="text-[11px] text-slate-500">{chk.serviceName}</div>
                      </td>

                      <td className="py-3 px-4">
                        <span className="font-semibold text-slate-800">{chk.roomName}</span>
                      </td>

                      <td className="py-3 px-4">
                        <span className="font-mono font-bold text-xs bg-amber-50 text-amber-950 border border-amber-200 px-2 py-0.5 rounded">
                          {chk.securityCode}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        {hasAllergy ? (
                          <div className="text-rose-800 font-semibold flex items-center gap-1 bg-rose-50 px-2 py-0.5 rounded border border-rose-200 w-fit">
                            <AlertTriangle className="w-3 h-3 text-rose-600 shrink-0" />
                            <span>{chk.allergies}</span>
                          </div>
                        ) : (
                          <span className="text-slate-400 italic">None recorded</span>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-800">{chk.parentName}</div>
                        <div className="text-[11px] text-slate-500 flex items-center gap-1">
                          <Phone className="w-3 h-3 text-slate-400" />
                          <span>{chk.parentPhone}</span>
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5">
                          <span className={`w-2 h-2 rounded-full ${isCheckedIn ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`}></span>
                          <span className="font-semibold text-slate-800">{chk.status}</span>
                        </div>
                        <div className="text-[10px] text-slate-400 tabular-nums">
                          In: {new Date(chk.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          {chk.checkOutTime && ` · Out: ${new Date(chk.checkOutTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex items-center gap-1.5">
                          {isCheckedIn ? (
                            <button
                              onClick={() => {
                                setCheckoutTarget(chk);
                                setInputSecurityCode('');
                                setCheckoutFeedback(null);
                              }}
                              className="inline-flex items-center gap-1 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
                            >
                              <DoorOpen className="w-3.5 h-3.5" />
                              <span>Verify & Release</span>
                            </button>
                          ) : (
                            <span className="text-emerald-700 font-semibold flex items-center gap-1 text-[11px]">
                              <Check className="w-3.5 h-3.5" /> Dismissed
                            </span>
                          )}

                          <button
                            onClick={() => setBadgeToReprint(chk)}
                            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                            title="Reprint badge"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Security Check-out Code Challenge Modal */}
      {checkoutTarget && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden">
            
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-600 text-white flex items-center justify-center">
                  <KeyRound className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-display text-base font-bold">Child Dismissal Authorization</h3>
                  <p className="text-[11px] text-slate-300">Verify parent security claim code</p>
                </div>
              </div>
              <button
                onClick={() => setCheckoutTarget(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleVerifyCheckout} className="p-6 space-y-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div className="font-bold text-slate-900 text-sm">{checkoutTarget.childName}</div>
                <div className="text-slate-600 text-[11px]">Room: {checkoutTarget.roomName}</div>
                <div className="text-slate-600 text-[11px]">Parent: {checkoutTarget.parentName} ({checkoutTarget.parentPhone})</div>
                <div className="text-slate-400 text-[10px] mt-1">
                  Expected Tag Match: <span className="font-mono font-bold text-slate-700">{checkoutTarget.securityCode}</span>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Enter Code on Parent Claim Ticket *
                </label>
                <input
                  type="text"
                  required
                  autoFocus
                  value={inputSecurityCode}
                  onChange={(e) => setInputSecurityCode(e.target.value)}
                  placeholder={`e.g. ${checkoutTarget.securityCode}`}
                  className="w-full text-center py-2.5 bg-slate-50 border-2 border-slate-300 focus:border-amber-600 rounded-xl text-lg font-mono font-bold tracking-widest text-slate-900 uppercase focus:outline-none"
                />
              </div>

              {checkoutFeedback && (
                <div className={`p-3 rounded-lg text-center font-medium ${
                  checkoutFeedback.success 
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' 
                    : 'bg-rose-50 text-rose-800 border border-rose-200'
                }`}>
                  {checkoutFeedback.message}
                </div>
              )}

              <div className="pt-2 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setCheckoutTarget(null)}
                  className="px-4 py-2 text-slate-600 hover:text-slate-800 bg-slate-100 rounded-lg font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-white bg-slate-900 hover:bg-slate-800 rounded-lg font-semibold shadow-xs cursor-pointer"
                >
                  Authorize Release
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* Badge Reprint Preview Modal */}
      {badgeToReprint && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden p-6 text-xs space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-200">
              <h3 className="font-bold text-slate-900 text-sm">Reprint Security Badge</h3>
              <button onClick={() => setBadgeToReprint(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div id="printable-area" className="bg-white border-2 border-slate-900 rounded-2xl p-4">
              <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                <div className="font-display font-bold text-xs text-amber-900">GraceKids Sunday School</div>
                <span className="font-mono text-xs font-bold bg-amber-100 text-amber-950 px-2 py-0.5 rounded">
                  {badgeToReprint.securityCode}
                </span>
              </div>
              <div className="py-3 text-center">
                <h4 className="font-display text-2xl font-bold text-slate-900">{badgeToReprint.childName}</h4>
                <div className="text-xs font-semibold text-slate-700 mt-1">{badgeToReprint.roomName}</div>
              </div>
              {badgeToReprint.allergies && badgeToReprint.allergies !== 'None' && (
                <div className="bg-rose-50 border border-rose-200 p-1.5 rounded text-center font-bold text-rose-900 text-[10px] mb-2">
                  ALLERGY: {badgeToReprint.allergies}
                </div>
              )}
              <div className="pt-2 border-t border-slate-100 flex justify-between text-[10px] text-slate-500">
                <span>Parent: {badgeToReprint.parentName}</span>
                <span>Code: {badgeToReprint.securityCode}</span>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setBadgeToReprint(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 rounded-lg font-semibold"
              >
                Close
              </button>
              <button
                onClick={() => window.print()}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Badge</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Kiosk Modal Launcher */}
      <CheckInKioskModal
        isOpen={isKioskOpen}
        onClose={() => setIsKioskOpen(false)}
      />

    </div>
  );
};
