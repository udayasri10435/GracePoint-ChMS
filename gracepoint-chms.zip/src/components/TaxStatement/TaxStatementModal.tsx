import React, { useRef } from 'react';
import { Member, Donation } from '../../types';
import { useChurch } from '../../context/ChurchContext';
import { X, Printer, Download, CheckCircle, ShieldCheck } from 'lucide-react';

interface TaxStatementModalProps {
  member: Member | null;
  onClose: () => void;
}

export const TaxStatementModal: React.FC<TaxStatementModalProps> = ({ member, onClose }) => {
  const { donations } = useChurch();

  if (!member) return null;

  const memberDonations = donations.filter(d => d.memberId === member.id);
  const totalAmount = memberDonations.reduce((sum, d) => sum + d.amount, 0);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto no-print">
      <div className="bg-white rounded-2xl max-w-3xl w-full shadow-2xl overflow-hidden my-6 border border-slate-200">
        
        {/* Modal Controls Bar */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between no-print">
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-sm">IRS 501(c)(3) Contribution Statement</span>
            <span className="text-xs text-slate-400">· Tax Year 2026</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save as PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Area */}
        <div id="printable-area" className="p-8 sm:p-10 space-y-6 text-slate-900 text-xs bg-white">
          
          {/* Church Letterhead */}
          <div className="flex justify-between items-start pb-6 border-b-2 border-slate-900">
            <div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded bg-slate-900 text-white flex items-center justify-center font-display font-bold text-sm">
                  GP
                </div>
                <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900">
                  GracePoint Community Church
                </h1>
              </div>
              <p className="text-slate-600 mt-1">12 Grace Lane · Springfield, ST 97201</p>
              <p className="text-slate-500 text-[11px]">Phone: (555) 887-1230 · contact@gracepointchurch.org</p>
            </div>

            <div className="text-right">
              <div className="font-bold text-sm text-slate-900 uppercase tracking-wider">Annual Contribution Statement</div>
              <div className="text-slate-600 mt-0.5">Tax Year: <strong className="font-semibold text-slate-900">2026</strong></div>
              <div className="text-[11px] text-slate-500 mt-0.5">Federal Tax ID (EIN): <span className="font-mono">84-2948192</span></div>
              <div className="text-[10px] text-emerald-800 font-semibold mt-1 flex items-center justify-end gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-700" /> 501(c)(3) Tax-Exempt Religious Org
              </div>
            </div>
          </div>

          {/* Donor Information */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex justify-between items-start">
            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Contributor Details</span>
              <div className="font-display font-bold text-base text-slate-900 mt-0.5">
                {member.firstName} {member.lastName}
              </div>
              <div className="text-slate-600 mt-0.5">{member.address}</div>
              {member.email && <div className="text-slate-500 text-[11px]">{member.email}</div>}
            </div>

            <div className="text-right">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Donor Reference</span>
              <div className="font-mono text-slate-800 mt-0.5">ID: {member.id.toUpperCase()}</div>
              <div className="text-slate-500 text-[11px]">Household: {member.householdName}</div>
              <div className="text-slate-500 text-[11px]">Date Issued: {new Date().toISOString().split('T')[0]}</div>
            </div>
          </div>

          {/* Itemized Contributions Table */}
          <div>
            <h3 className="font-bold text-slate-900 text-sm mb-2">Itemized Giving Ledger</h3>
            <table className="w-full text-left border-collapse border border-slate-200">
              <thead className="bg-slate-100 text-slate-700 font-semibold text-[11px] uppercase tracking-wider">
                <tr>
                  <th className="p-2 border border-slate-200">Date</th>
                  <th className="p-2 border border-slate-200">Receipt No.</th>
                  <th className="p-2 border border-slate-200">Fund Designation</th>
                  <th className="p-2 border border-slate-200">Method</th>
                  <th className="p-2 border border-slate-200 text-right">Deductible Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-sans">
                {memberDonations.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-4 text-center text-slate-500 italic">
                      No deductible gifts recorded for this donor in tax year 2026.
                    </td>
                  </tr>
                ) : (
                  memberDonations.map((d) => (
                    <tr key={d.id}>
                      <td className="p-2 border border-slate-200 tabular-nums">{d.date}</td>
                      <td className="p-2 border border-slate-200 font-mono text-[11px] text-slate-600">{d.receiptNumber}</td>
                      <td className="p-2 border border-slate-200 font-medium text-slate-800">{d.fund}</td>
                      <td className="p-2 border border-slate-200 text-slate-600">{d.method} {d.checkNumber ? `#${d.checkNumber}` : ''}</td>
                      <td className="p-2 border border-slate-200 text-right font-bold text-slate-900 tabular-nums">
                        ${d.amount.toFixed(2)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
              <tfoot className="bg-slate-50 font-bold">
                <tr>
                  <td colSpan={4} className="p-3 border border-slate-200 text-right uppercase tracking-wider text-slate-800">
                    Total Tax-Deductible Contributions:
                  </td>
                  <td className="p-3 border border-slate-200 text-right text-base text-slate-900 tabular-nums">
                    ${totalAmount.toFixed(2)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Legal IRS Disclosure */}
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-[11px] text-slate-600 leading-relaxed">
            <strong className="text-slate-800">IRS Compliance Certification:</strong> Thank you for your faithful partnership with GracePoint Community Church. No goods or services were provided in exchange for this contribution other than intangible religious benefits. Please keep this written acknowledgment for your personal federal and state income tax records.
          </div>

          {/* Pastoral & Financial Officer Signatures */}
          <div className="pt-8 border-t border-slate-200 grid grid-cols-2 gap-8 text-center text-xs">
            <div>
              <div className="font-display font-bold text-slate-900 text-sm italic mb-1">Pastor David Sterling</div>
              <div className="w-48 h-px bg-slate-400 mx-auto mb-1"></div>
              <div className="text-slate-600 font-medium">David Sterling, Senior Pastor</div>
              <div className="text-slate-400 text-[10px]">GracePoint Community Church</div>
            </div>

            <div>
              <div className="font-display font-bold text-slate-900 text-sm italic mb-1">Martha Sterling</div>
              <div className="w-48 h-px bg-slate-400 mx-auto mb-1"></div>
              <div className="text-slate-600 font-medium">Martha Sterling, Ministry Treasurer</div>
              <div className="text-slate-400 text-[10px]">Financial Stewardship Council</div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
