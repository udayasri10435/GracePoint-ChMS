import React, { useState } from 'react';
import { useChurch } from '../../context/ChurchContext';
import { FundCategory, PaymentMethod } from '../../types';
import { X, HeartHandshake, CheckCircle } from 'lucide-react';

interface RecordGiftModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RecordGiftModal: React.FC<RecordGiftModalProps> = ({ isOpen, onClose }) => {
  const { members, addDonation } = useChurch();

  const [donorId, setDonorId] = useState<string>(members[0]?.id || 'anon');
  const [customDonorName, setCustomDonorName] = useState('');
  const [amount, setAmount] = useState<string>('150.00');
  const [fund, setFund] = useState<FundCategory>('Tithe & General');
  const [method, setMethod] = useState<PaymentMethod>('Card');
  const [checkNumber, setCheckNumber] = useState('');
  const [isRecurring, setIsRecurring] = useState(false);
  const [frequency, setFrequency] = useState<'Weekly' | 'Monthly'>('Monthly');
  const [memo, setMemo] = useState('');
  const [successReceipt, setSuccessReceipt] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) return;

    let memberName = 'Anonymous Giver';
    let memberEmail: string | undefined = undefined;

    if (donorId === 'anon') {
      memberName = customDonorName.trim() || 'Anonymous Giver';
    } else {
      const selected = members.find(m => m.id === donorId);
      if (selected) {
        memberName = `${selected.firstName} ${selected.lastName}`;
        memberEmail = selected.email;
      }
    }

    const created = addDonation({
      memberId: donorId,
      memberName,
      memberEmail,
      amount: numAmount,
      fund,
      date: new Date().toISOString().split('T')[0],
      method,
      checkNumber: method === 'Check' ? checkNumber : undefined,
      recurring: isRecurring,
      frequency: isRecurring ? frequency : 'One-time',
      memo: memo.trim() || undefined,
      status: 'Completed',
    });

    setSuccessReceipt(created.receiptNumber);
  };

  const handleResetAndClose = () => {
    setSuccessReceipt(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden">
        
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
              <HeartHandshake className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display text-lg font-bold text-white">Record Contribution</h3>
              <p className="text-xs text-slate-300">Log tithe, offering, or building fund pledge</p>
            </div>
          </div>
          <button
            onClick={handleResetAndClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {successReceipt ? (
          <div className="p-8 text-center space-y-4 text-xs">
            <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle className="w-6 h-6" />
            </div>
            <h4 className="font-display text-xl font-bold text-slate-900">Donation Recorded Successfully</h4>
            <p className="text-slate-600">
              Contribution receipt <strong className="text-slate-900 font-mono">{successReceipt}</strong> has been logged to the church ledger and member tax record.
            </p>
            <div className="pt-4 flex justify-center gap-3">
              <button
                onClick={() => setSuccessReceipt(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Record Another Gift
              </button>
              <button
                onClick={handleResetAndClose}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
            
            {/* Donor Selection */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Donor Profile</label>
              <select
                value={donorId}
                onChange={(e) => setDonorId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5"
              >
                <option value="anon">Unenrolled / Anonymous Giver</option>
                <optgroup label="Church Members & Regular Attenders">
                  {members.map(m => (
                    <option key={m.id} value={m.id}>
                      {m.firstName} {m.lastName} ({m.membershipStatus})
                    </option>
                  ))}
                </optgroup>
              </select>
            </div>

            {donorId === 'anon' && (
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Custom Name or Envelope #</label>
                <input
                  type="text"
                  value={customDonorName}
                  onChange={(e) => setCustomDonorName(e.target.value)}
                  placeholder="e.g. Visitor Envelope #48 or Cash Plate"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5"
                />
              </div>
            )}

            {/* Amount and Fund */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Amount ($ USD) *</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-semibold">$</span>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    required
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full pl-7 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-semibold tabular-nums focus:ring-1 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Designated Fund *</label>
                <select
                  value={fund}
                  onChange={(e) => setFund(e.target.value as FundCategory)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
                >
                  <option value="Tithe & General">Tithe & General Operating</option>
                  <option value="Building Campaign">Building & Expansion Campaign</option>
                  <option value="Missions & Outreach">Global Missions & Outreach</option>
                  <option value="Youth & Camp">Youth Camp Scholarship</option>
                  <option value="Benevolence Fund">Local Benevolence & Relief</option>
                </select>
              </div>
            </div>

            {/* Payment Method */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Payment Method</label>
                <select
                  value={method}
                  onChange={(e) => setMethod(e.target.value as PaymentMethod)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
                >
                  <option value="Card">Debit / Credit Card</option>
                  <option value="ACH Transfer">ACH Bank Transfer</option>
                  <option value="Check">Physical Check</option>
                  <option value="Cash">Cash / Currency</option>
                </select>
              </div>

              {method === 'Check' ? (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Check Number</label>
                  <input
                    type="text"
                    value={checkNumber}
                    onChange={(e) => setCheckNumber(e.target.value)}
                    placeholder="e.g. 1042"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
                  />
                </div>
              ) : (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Recurring Cadence</label>
                  <select
                    value={isRecurring ? frequency : 'One-time'}
                    onChange={(e) => {
                      if (e.target.value === 'One-time') {
                        setIsRecurring(false);
                      } else {
                        setIsRecurring(true);
                        setFrequency(e.target.value as any);
                      }
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
                  >
                    <option value="One-time">One-time Gift</option>
                    <option value="Weekly">Recurring Weekly</option>
                    <option value="Monthly">Recurring Monthly</option>
                  </select>
                </div>
              )}
            </div>

            {/* Memo / Note */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Memo / Designation Details</label>
              <input
                type="text"
                value={memo}
                onChange={(e) => setMemo(e.target.value)}
                placeholder="e.g. In memory of, or dedicated to outreach event"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2"
              />
            </div>

            {/* Actions */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={handleResetAndClose}
                className="px-4 py-2 font-semibold text-slate-600 hover:text-slate-800 bg-slate-100 rounded-lg transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition-colors cursor-pointer"
              >
                Record Contribution
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
