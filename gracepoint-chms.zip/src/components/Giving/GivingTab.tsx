import React, { useState, useMemo } from 'react';
import { useChurch } from '../../context/ChurchContext';
import { FundCategory, PaymentMethod, Member } from '../../types';
import { 
  HeartHandshake, 
  Search, 
  Plus, 
  Download, 
  Globe, 
  Filter, 
  CreditCard, 
  Landmark, 
  FileText, 
  TrendingUp, 
  CheckCircle,
  Clock
} from 'lucide-react';

interface GivingTabProps {
  onOpenRecordGift: () => void;
  onOpenGivingPortal: () => void;
  onGenerateTaxStatement: (member: Member) => void;
}

export const GivingTab: React.FC<GivingTabProps> = ({
  onOpenRecordGift,
  onOpenGivingPortal,
  onGenerateTaxStatement,
}) => {
  const { donations, members } = useChurch();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFund, setSelectedFund] = useState<string>('all');
  const [selectedMethod, setSelectedMethod] = useState<string>('all');

  // Stats calculation
  const totalAmount = donations.reduce((sum, d) => sum + d.amount, 0);
  const thisMonthTotal = donations
    .filter(d => d.date.startsWith('2026-09'))
    .reduce((sum, d) => sum + d.amount, 0);
  const recurringCount = donations.filter(d => d.recurring).length;
  const avgGift = donations.length > 0 ? totalAmount / donations.length : 0;

  // Filtered donations
  const filteredDonations = useMemo(() => {
    return donations.filter(d => {
      if (selectedFund !== 'all' && d.fund !== selectedFund) return false;
      if (selectedMethod !== 'all' && d.method !== selectedMethod) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = d.memberName.toLowerCase().includes(q);
        const matchesReceipt = d.receiptNumber.toLowerCase().includes(q);
        const matchesMemo = (d.memo || '').toLowerCase().includes(q);
        return matchesName || matchesReceipt || matchesMemo;
      }
      return true;
    });
  }, [donations, selectedFund, selectedMethod, searchQuery]);

  // Export Giving to CSV
  const handleExportCSV = () => {
    const headers = ['Receipt No', 'Date', 'Donor Name', 'Amount', 'Fund', 'Payment Method', 'Recurring', 'Memo'];
    const rows = filteredDonations.map(d => [
      `"${d.receiptNumber}"`,
      `"${d.date}"`,
      `"${d.memberName}"`,
      `"${d.amount.toFixed(2)}"`,
      `"${d.fund}"`,
      `"${d.method}"`,
      `"${d.recurring ? 'Yes' : 'No'}"`,
      `"${(d.memo || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `gracepoint_giving_ledger_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      
      {/* Header and Action Buttons */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h2 className="font-display text-2xl font-bold text-slate-900">Giving & Stewardship</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Financial ledger, fund accounting, online donation records, and tax acknowledgment statements
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={onOpenGivingPortal}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-amber-950 bg-amber-100 hover:bg-amber-200 border border-amber-300 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <Globe className="w-3.5 h-3.5 text-amber-800" />
            <span>Online Giving Portal</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export Ledger</span>
          </button>

          <button
            onClick={onOpenRecordGift}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Record Gift</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <span className="text-xs font-medium text-slate-500 block mb-1">Total Giving (YTD)</span>
          <div className="font-display text-2xl font-bold text-slate-900 tabular-nums">
            ${totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-emerald-700 font-medium mt-1 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" /> Across all designated funds
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <span className="text-xs font-medium text-slate-500 block mb-1">September Month-to-Date</span>
          <div className="font-display text-2xl font-bold text-slate-900 tabular-nums">
            ${thisMonthTotal.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {donations.filter(d => d.date.startsWith('2026-09')).length} transactions recorded
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <span className="text-xs font-medium text-slate-500 block mb-1">Average Gift Size</span>
          <div className="font-display text-2xl font-bold text-slate-900 tabular-nums">
            ${avgGift.toFixed(2)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Healthy congregational participation
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <span className="text-xs font-medium text-slate-500 block mb-1">Automated Recurring</span>
          <div className="font-display text-2xl font-bold text-slate-900 tabular-nums">
            {recurringCount}
          </div>
          <div className="text-[11px] text-amber-800 font-medium mt-1">
            Predictable recurring partners
          </div>
        </div>

      </div>

      {/* Building Campaign Spotlight Banner */}
      <div className="bg-gradient-to-r from-amber-900/90 to-slate-900 text-white rounded-xl p-5 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="space-y-1">
          <span className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider">
            Capital Pledge Campaign
          </span>
          <h3 className="font-display text-lg font-bold">Sanctuary Acoustic & Building Expansion</h3>
          <p className="text-xs text-slate-300 max-w-xl">
            Raising $50,000 for children’s wing safety doors, sanctuary soundboard acoustic panels, and north campus fellowship space.
          </p>
        </div>

        <div className="w-full md:w-72 bg-white/10 p-3 rounded-lg border border-white/20 text-xs">
          <div className="flex justify-between font-medium mb-1">
            <span>Progress: $1,200</span>
            <span className="text-amber-300 font-semibold">$50,000 Goal</span>
          </div>
          <div className="w-full bg-black/40 h-2 rounded-full overflow-hidden">
            <div className="bg-amber-400 h-full rounded-full" style={{ width: '24%' }} />
          </div>
          <div className="text-right text-[10px] text-slate-300 mt-1">Phase 1 Groundwork Active</div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search donor name, receipt number, or memo..."
              className="w-full pl-9 pr-3 py-2 text-xs text-slate-900 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
          </div>

          <div>
            <select
              value={selectedFund}
              onChange={(e) => setSelectedFund(e.target.value)}
              className="w-full py-2 px-3 text-xs text-slate-700 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none cursor-pointer"
            >
              <option value="all">All Funds</option>
              <option value="Tithe & General">Tithe & General Operating</option>
              <option value="Building Campaign">Building Campaign</option>
              <option value="Missions & Outreach">Missions & Outreach</option>
              <option value="Youth & Camp">Youth & Camp</option>
              <option value="Benevolence Fund">Benevolence Fund</option>
            </select>
          </div>

          <div>
            <select
              value={selectedMethod}
              onChange={(e) => setSelectedMethod(e.target.value)}
              className="w-full py-2 px-3 text-xs text-slate-700 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none cursor-pointer"
            >
              <option value="all">All Payment Methods</option>
              <option value="Card">Card</option>
              <option value="ACH Transfer">ACH Bank Transfer</option>
              <option value="Check">Check</option>
              <option value="Cash">Cash</option>
            </select>
          </div>

        </div>
      </div>

      {/* Financial Transactions Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Receipt & Date</th>
                <th className="py-3 px-4">Donor Name</th>
                <th className="py-3 px-4">Fund Category</th>
                <th className="py-3 px-4">Method & Memo</th>
                <th className="py-3 px-4 text-right">Amount</th>
                <th className="py-3 px-4 text-right">Tax Statement</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredDonations.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No transactions match your search criteria.
                  </td>
                </tr>
              ) : (
                filteredDonations.map((d) => {
                  const matchedMember = members.find(m => m.id === d.memberId);
                  return (
                    <tr key={d.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-mono text-slate-800 font-medium">{d.receiptNumber}</div>
                        <div className="text-[11px] text-slate-400 tabular-nums">{d.date}</div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{d.memberName}</div>
                        {d.memberEmail && (
                          <div className="text-[11px] text-slate-400 truncate max-w-[180px]">{d.memberEmail}</div>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        <span className="font-medium text-slate-800">{d.fund}</span>
                        {d.recurring && (
                          <span className="ml-1.5 text-[10px] bg-amber-50 text-amber-800 px-1.5 py-0.2 rounded font-medium">
                            Recurring
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        <div className="text-slate-700 font-medium flex items-center gap-1">
                          {d.method === 'Card' && <CreditCard className="w-3 h-3 text-slate-400" />}
                          {d.method === 'ACH Transfer' && <Landmark className="w-3 h-3 text-slate-400" />}
                          <span>{d.method}</span>
                          {d.checkNumber && <span className="font-mono text-slate-500">#{d.checkNumber}</span>}
                        </div>
                        {d.memo && (
                          <div className="text-[11px] text-slate-500 italic truncate max-w-[200px]">{d.memo}</div>
                        )}
                      </td>

                      <td className="py-3 px-4 text-right">
                        <span className="font-bold text-slate-900 text-sm tabular-nums">
                          ${d.amount.toFixed(2)}
                        </span>
                        <div className="text-[10px] text-emerald-700 font-medium flex items-center justify-end gap-0.5">
                          <CheckCircle className="w-3 h-3" /> Deposited
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right">
                        {matchedMember ? (
                          <button
                            onClick={() => onGenerateTaxStatement(matchedMember)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-slate-700 bg-slate-100 hover:bg-slate-200 rounded font-medium transition-colors cursor-pointer"
                            title="Generate Annual Tax Receipt"
                          >
                            <FileText className="w-3 h-3 text-amber-800" />
                            <span>Statement</span>
                          </button>
                        ) : (
                          <span className="text-[11px] text-slate-400 italic">Anonymous</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
