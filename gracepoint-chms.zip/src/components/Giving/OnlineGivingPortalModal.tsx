import React, { useState } from 'react';
import { useChurch } from '../../context/ChurchContext';
import { FundCategory, PaymentMethod } from '../../types';
import { X, Heart, ShieldCheck, CreditCard, Landmark, CheckCircle } from 'lucide-react';

interface OnlineGivingPortalModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const OnlineGivingPortalModal: React.FC<OnlineGivingPortalModalProps> = ({ isOpen, onClose }) => {
  const { members, addDonation } = useChurch();

  const [selectedMemberId, setSelectedMemberId] = useState(members[0]?.id || 'anon');
  const [selectedAmount, setSelectedAmount] = useState<number>(100);
  const [customAmount, setCustomAmount] = useState<string>('');
  const [fund, setFund] = useState<FundCategory>('Tithe & General');
  const [frequency, setFrequency] = useState<'One-time' | 'Weekly' | 'Monthly'>('Monthly');
  const [paymentType, setPaymentType] = useState<'card' | 'ach'>('card');
  const [coverFees, setCoverFees] = useState(true);
  const [donorName, setDonorName] = useState(members[0] ? `${members[0].firstName} ${members[0].lastName}` : 'Marcus Miller');
  const [cardNumber, setCardNumber] = useState('•••• •••• •••• 4821');
  const [isSuccess, setIsSuccess] = useState(false);
  const [lastReceipt, setLastReceipt] = useState<string>('');

  if (!isOpen) return null;

  const baseAmount = customAmount ? parseFloat(customAmount) || 0 : selectedAmount;
  const processingFee = coverFees ? Number((baseAmount * 0.022 + 0.30).toFixed(2)) : 0;
  const totalCharge = baseAmount + processingFee;

  const handleMemberChange = (id: string) => {
    setSelectedMemberId(id);
    const m = members.find(mem => mem.id === id);
    if (m) {
      setDonorName(`${m.firstName} ${m.lastName}`);
    }
  };

  const handleProcessGift = (e: React.FormEvent) => {
    e.preventDefault();
    if (baseAmount <= 0) return;

    const donation = addDonation({
      memberId: selectedMemberId,
      memberName: donorName,
      amount: totalCharge,
      fund,
      date: new Date().toISOString().split('T')[0],
      method: paymentType === 'card' ? 'Card' : 'ACH Transfer',
      recurring: frequency !== 'One-time',
      frequency,
      memo: `Online Giving Portal (${frequency}) ${coverFees ? '+ Processing fee covered' : ''}`,
      status: 'Completed',
    });

    setLastReceipt(donation.receiptNumber);
    setIsSuccess(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden my-6 border border-slate-100">
        
        {/* Portal Header */}
        <div className="bg-gradient-to-r from-amber-900 to-slate-900 text-white p-6 text-center relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1 rounded-full text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="w-10 h-10 rounded-full bg-white/15 backdrop-blur-xs flex items-center justify-center mx-auto mb-2 text-amber-300">
            <Heart className="w-5 h-5 fill-current" />
          </div>
          <h3 className="font-display text-xl font-bold tracking-tight">GracePoint Giving Portal</h3>
          <p className="text-xs text-amber-200/90 mt-1">Generosity fuels gospel ministry, outreach, and discipleship</p>
        </div>

        {isSuccess ? (
          <div className="p-8 text-center space-y-4 text-xs">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto shadow-xs">
              <CheckCircle className="w-8 h-8" />
            </div>
            <div>
              <h4 className="font-display text-xl font-bold text-slate-900">Thank You for Your Generosity!</h4>
              <p className="text-slate-600 mt-1">
                Your gift of <strong className="text-slate-900 font-bold">${totalCharge.toFixed(2)}</strong> to <span className="font-semibold">{fund}</span> has been processed.
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-left font-mono text-[11px] text-slate-600 space-y-1">
              <div>Receipt ID: {lastReceipt}</div>
              <div>Giver: {donorName}</div>
              <div>Cadence: {frequency}</div>
              <div>Status: Verified & Deductible</div>
            </div>

            <button
              onClick={() => {
                setIsSuccess(false);
                onClose();
              }}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg transition-colors cursor-pointer"
            >
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={handleProcessGift} className="p-6 space-y-4 text-xs">
            
            {/* Simulation Persona Selector */}
            <div className="p-2.5 bg-amber-50/80 rounded-lg border border-amber-200/80">
              <label className="block text-[11px] font-semibold text-amber-950 mb-1">
                Simulating Giving As (Member Profile)
              </label>
              <select
                value={selectedMemberId}
                onChange={(e) => handleMemberChange(e.target.value)}
                className="w-full bg-white border border-amber-300 rounded p-1.5 text-xs text-slate-800"
              >
                {members.map(m => (
                  <option key={m.id} value={m.id}>
                    {m.firstName} {m.lastName} ({m.membershipStatus})
                  </option>
                ))}
              </select>
            </div>

            {/* Frequency Selector */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1.5">Giving Frequency</label>
              <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 rounded-lg">
                {(['One-time', 'Weekly', 'Monthly'] as const).map(freq => (
                  <button
                    key={freq}
                    type="button"
                    onClick={() => setFrequency(freq)}
                    className={`py-1.5 rounded-md font-medium text-xs transition-colors cursor-pointer ${
                      frequency === freq 
                        ? 'bg-white text-slate-900 shadow-xs font-semibold' 
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {freq}
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Amount Pills */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1.5">Select Gift Amount</label>
              <div className="grid grid-cols-4 gap-2 mb-2">
                {[50, 100, 250, 500].map(amt => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => {
                      setSelectedAmount(amt);
                      setCustomAmount('');
                    }}
                    className={`py-2 text-xs font-bold rounded-lg border transition-colors cursor-pointer ${
                      selectedAmount === amt && !customAmount
                        ? 'bg-amber-100 text-amber-950 border-amber-400 ring-1 ring-amber-400'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    ${amt}
                  </button>
                ))}
              </div>

              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-semibold">$</span>
                <input
                  type="number"
                  min="1"
                  step="0.01"
                  value={customAmount}
                  onChange={(e) => {
                    setCustomAmount(e.target.value);
                    setSelectedAmount(0);
                  }}
                  placeholder="Or enter custom amount..."
                  className="w-full pl-7 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                />
              </div>
            </div>

            {/* Fund Selector */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Designated Ministry Fund</label>
              <select
                value={fund}
                onChange={(e) => setFund(e.target.value as FundCategory)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs"
              >
                <option value="Tithe & General">Tithe & General Operating</option>
                <option value="Building Campaign">Sanctuary Expansion & Building Campaign</option>
                <option value="Missions & Outreach">Global Missions & Benevolence</option>
                <option value="Youth & Camp">Youth Camp Scholarships</option>
                <option value="Benevolence Fund">Local Compassion & Families Relief</option>
              </select>
            </div>

            {/* Payment Method Selector */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1.5">Payment Method</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentType('card')}
                  className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border text-xs font-medium cursor-pointer transition-colors ${
                    paymentType === 'card'
                      ? 'bg-amber-50 text-amber-950 border-amber-300 font-semibold'
                      : 'bg-white text-slate-600 border-slate-200'
                  }`}
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>Card</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentType('ach')}
                  className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border text-xs font-medium cursor-pointer transition-colors ${
                    paymentType === 'ach'
                      ? 'bg-amber-50 text-amber-950 border-amber-300 font-semibold'
                      : 'bg-white text-slate-600 border-slate-200'
                  }`}
                >
                  <Landmark className="w-3.5 h-3.5" />
                  <span>Bank ACH</span>
                </button>
              </div>
            </div>

            {/* Simulated Payment Credentials */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <div>
                <label className="block text-[11px] text-slate-500 mb-0.5">Cardholder / Account Name</label>
                <input
                  type="text"
                  value={donorName}
                  onChange={(e) => setDonorName(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded p-1.5 text-xs"
                />
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div className="col-span-2">
                  <label className="block text-[11px] text-slate-500 mb-0.5">Card Number</label>
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded p-1.5 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500 mb-0.5">Exp / CVC</label>
                  <input
                    type="text"
                    defaultValue="09/28 · 382"
                    className="w-full bg-white border border-slate-200 rounded p-1.5 text-xs font-mono text-center"
                  />
                </div>
              </div>
            </div>

            {/* Cover Processing Fees checkbox */}
            <label className="flex items-start gap-2 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={coverFees}
                onChange={(e) => setCoverFees(e.target.checked)}
                className="mt-0.5 rounded text-amber-600 focus:ring-amber-500"
              />
              <span className="text-[11px] text-slate-600 leading-tight">
                Add <strong className="text-slate-800">${processingFee.toFixed(2)}</strong> to cover processing costs so 100% of my gift goes directly to ministry.
              </span>
            </label>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer text-xs"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Give ${totalCharge.toFixed(2)} {frequency !== 'One-time' ? `(${frequency})` : 'Now'}</span>
            </button>

            <div className="flex items-center justify-center gap-1.5 text-[10px] text-slate-400 pt-1">
              <ShieldCheck className="w-3 h-3 text-slate-400" />
              <span>256-bit SSL Encrypted Church Giving Processor</span>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
